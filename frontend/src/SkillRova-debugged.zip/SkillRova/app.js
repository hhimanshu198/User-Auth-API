const STORAGE_KEY = "skillrova-progress-v1";
const LEGACY_STORAGE_KEYS = [
  "career-day-simulator-progress-v2",
  "career-day-simulator-progress-v1"
];

const baseCareers = [
  { title: "Product Manager", field: "Technology", mission: "decide what the team should build next", focus: "prioritization", stakeholder: "engineering lead", pressure: "a launch date is slipping", difficulty: "High", traits: ["strategy", "communication", "tradeoffs"], tools: ["Roadmap", "Analytics", "User feedback"] },
  { title: "Software Engineer", field: "Technology", mission: "fix a risky product bug before release", focus: "debugging", stakeholder: "product manager", pressure: "users are blocked", difficulty: "High", traits: ["logic", "patience", "systems thinking"], tools: ["Code editor", "Logs", "Pull requests"] },
  { title: "UX Designer", field: "Design", mission: "make a confusing flow easier for new users", focus: "user empathy", stakeholder: "research lead", pressure: "testing starts tomorrow", difficulty: "Medium", traits: ["empathy", "visual thinking", "experimentation"], tools: ["Prototype", "Research notes", "Design review"] },
  { title: "Data Analyst", field: "Technology", mission: "explain why a key metric changed", focus: "evidence", stakeholder: "growth manager", pressure: "leadership needs the answer today", difficulty: "Medium", traits: ["curiosity", "accuracy", "storytelling"], tools: ["Dashboard", "Spreadsheet", "SQL query"] },
  { title: "Data Scientist", field: "Technology", mission: "judge whether a prediction model is reliable", focus: "model quality", stakeholder: "operations director", pressure: "the model may affect real decisions", difficulty: "High", traits: ["statistics", "experimentation", "skepticism"], tools: ["Notebook", "Model report", "Validation data"] },
  { title: "Cybersecurity Analyst", field: "Technology", mission: "respond to a suspicious login pattern", focus: "risk triage", stakeholder: "IT manager", pressure: "a client system may be exposed", difficulty: "High", traits: ["calm", "attention to detail", "risk thinking"], tools: ["Security alerts", "Access logs", "Incident checklist"] },
  { title: "Web Developer", field: "Technology", mission: "ship a landing page update without breaking checkout", focus: "implementation", stakeholder: "marketing manager", pressure: "the campaign goes live tonight", difficulty: "Medium", traits: ["craft", "testing", "speed"], tools: ["Browser", "CSS", "Issue tracker"] },
  { title: "Video Game Designer", field: "Design", mission: "rebalance a level that players keep quitting", focus: "player experience", stakeholder: "creative director", pressure: "the playtest report is poor", difficulty: "Medium", traits: ["creativity", "systems thinking", "iteration"], tools: ["Level editor", "Playtest notes", "Balance sheet"] },
  { title: "Marketing Manager", field: "Business", mission: "choose a launch message for a new product", focus: "audience insight", stakeholder: "sales lead", pressure: "the campaign budget is limited", difficulty: "Medium", traits: ["positioning", "creativity", "measurement"], tools: ["Campaign brief", "Audience segments", "Budget tracker"] },
  { title: "Financial Analyst", field: "Business", mission: "recommend where to cut costs without hurting growth", focus: "financial judgment", stakeholder: "finance director", pressure: "the forecast changed overnight", difficulty: "High", traits: ["numeracy", "judgment", "precision"], tools: ["Forecast model", "Budget file", "Variance report"] },
  { title: "Accountant", field: "Business", mission: "close the books and catch a mismatch", focus: "accuracy", stakeholder: "business owner", pressure: "tax filing is due soon", difficulty: "Medium", traits: ["precision", "consistency", "ethics"], tools: ["Ledger", "Receipts", "Reconciliation sheet"] },
  { title: "Entrepreneur", field: "Business", mission: "decide how to use a small amount of startup money", focus: "resourcefulness", stakeholder: "first customer", pressure: "cash runway is short", difficulty: "High", traits: ["initiative", "sales", "resilience"], tools: ["Pitch deck", "Customer calls", "Cash tracker"] },
  { title: "Project Manager", field: "Business", mission: "keep a cross-functional project on schedule", focus: "coordination", stakeholder: "program sponsor", pressure: "two teams disagree on scope", difficulty: "Medium", traits: ["organization", "communication", "follow-through"], tools: ["Timeline", "Risk log", "Status report"] },
  { title: "Sales Manager", field: "Business", mission: "save a deal without overpromising", focus: "negotiation", stakeholder: "major client", pressure: "quarter-end targets are close", difficulty: "High", traits: ["persuasion", "listening", "discipline"], tools: ["CRM", "Proposal", "Call notes"] },
  { title: "Human Resources Specialist", field: "Business", mission: "handle a sensitive employee issue fairly", focus: "people judgment", stakeholder: "team manager", pressure: "trust is low on the team", difficulty: "Medium", traits: ["fairness", "confidentiality", "listening"], tools: ["Policy guide", "Interview notes", "Case file"] },
  { title: "Supply Chain Manager", field: "Business", mission: "recover from a delayed shipment", focus: "logistics", stakeholder: "warehouse lead", pressure: "customers expect delivery this week", difficulty: "High", traits: ["planning", "negotiation", "calm"], tools: ["Inventory map", "Supplier update", "Delivery plan"] },
  { title: "Doctor", field: "Healthcare", mission: "choose next steps for a patient with unclear symptoms", focus: "clinical reasoning", stakeholder: "nurse practitioner", pressure: "the waiting room is full", difficulty: "High", traits: ["diagnosis", "empathy", "responsibility"], tools: ["Patient chart", "Lab results", "Care plan"] },
  { title: "Registered Nurse", field: "Healthcare", mission: "prioritize patient needs during a busy shift", focus: "patient care", stakeholder: "charge nurse", pressure: "two patients need attention now", difficulty: "High", traits: ["care", "prioritization", "stamina"], tools: ["Vitals board", "Medication list", "Shift handoff"] },
  { title: "Pharmacist", field: "Healthcare", mission: "catch a medication conflict before it reaches a patient", focus: "safety", stakeholder: "physician", pressure: "the pharmacy queue is backed up", difficulty: "High", traits: ["accuracy", "safety", "communication"], tools: ["Prescription queue", "Drug database", "Patient profile"] },
  { title: "Dentist", field: "Healthcare", mission: "help a nervous patient choose a treatment plan", focus: "patient communication", stakeholder: "dental assistant", pressure: "the patient is worried about cost", difficulty: "Medium", traits: ["precision", "reassurance", "planning"], tools: ["X-ray", "Treatment plan", "Cost estimate"] },
  { title: "Veterinarian", field: "Healthcare", mission: "diagnose a sick pet with limited information", focus: "diagnosis", stakeholder: "pet owner", pressure: "test results are incomplete", difficulty: "High", traits: ["observation", "empathy", "science"], tools: ["Exam notes", "Lab panel", "Owner history"] },
  { title: "Physical Therapist", field: "Healthcare", mission: "adjust a recovery plan after a setback", focus: "rehabilitation", stakeholder: "patient", pressure: "progress is slower than expected", difficulty: "Medium", traits: ["coaching", "patience", "body mechanics"], tools: ["Exercise plan", "Mobility notes", "Pain scale"] },
  { title: "Psychologist", field: "Social Impact", mission: "support a client through a difficult session", focus: "listening", stakeholder: "client", pressure: "the client is losing trust", difficulty: "High", traits: ["empathy", "boundaries", "analysis"], tools: ["Session notes", "Care goals", "Risk checklist"] },
  { title: "Social Worker", field: "Social Impact", mission: "connect a family to urgent support", focus: "advocacy", stakeholder: "case supervisor", pressure: "resources are limited", difficulty: "High", traits: ["advocacy", "resourcefulness", "care"], tools: ["Case file", "Benefits list", "Referral form"] },
  { title: "Teacher", field: "Education", mission: "help a class understand a hard concept", focus: "instruction", stakeholder: "student", pressure: "a quiz is tomorrow", difficulty: "Medium", traits: ["explanation", "patience", "adaptability"], tools: ["Lesson plan", "Whiteboard", "Student work"] },
  { title: "School Counselor", field: "Education", mission: "guide a student choosing subjects", focus: "career guidance", stakeholder: "parent", pressure: "course forms are due today", difficulty: "Medium", traits: ["listening", "guidance", "context"], tools: ["Course catalog", "Student profile", "Goal sheet"] },
  { title: "Lawyer", field: "Law and Public Service", mission: "prepare advice for a client under pressure", focus: "legal reasoning", stakeholder: "client", pressure: "a deadline is approaching", difficulty: "High", traits: ["reasoning", "writing", "ethics"], tools: ["Case file", "Statute notes", "Client brief"] },
  { title: "Police Officer", field: "Law and Public Service", mission: "de-escalate a tense public situation", focus: "judgment", stakeholder: "community member", pressure: "people are filming and worried", difficulty: "High", traits: ["calm", "judgment", "communication"], tools: ["Radio", "Incident protocol", "Witness notes"] },
  { title: "Firefighter", field: "Law and Public Service", mission: "coordinate a response during an emergency call", focus: "calm execution", stakeholder: "incident commander", pressure: "conditions are changing quickly", difficulty: "High", traits: ["teamwork", "courage", "discipline"], tools: ["Response plan", "Safety gear", "Radio update"] },
  { title: "Civil Servant", field: "Law and Public Service", mission: "improve a public service process", focus: "public value", stakeholder: "department head", pressure: "citizens are complaining", difficulty: "Medium", traits: ["service", "policy", "patience"], tools: ["Citizen feedback", "Policy memo", "Service dashboard"] },
  { title: "Civil Engineer", field: "Engineering", mission: "review a bridge design issue before approval", focus: "public safety", stakeholder: "site inspector", pressure: "construction is waiting", difficulty: "High", traits: ["safety", "math", "systems"], tools: ["Blueprint", "Load report", "Inspection note"] },
  { title: "Mechanical Engineer", field: "Engineering", mission: "fix a prototype that fails under stress", focus: "technical tradeoffs", stakeholder: "manufacturing lead", pressure: "demo day is close", difficulty: "High", traits: ["physics", "iteration", "problem solving"], tools: ["Prototype", "Test data", "CAD model"] },
  { title: "Biomedical Engineer", field: "Engineering", mission: "improve a medical device prototype", focus: "human safety", stakeholder: "clinical advisor", pressure: "testing found discomfort", difficulty: "High", traits: ["biology", "engineering", "ethics"], tools: ["Device test", "Clinical feedback", "Risk file"] },
  { title: "Architect", field: "Engineering", mission: "revise a building plan around budget and safety", focus: "spatial design", stakeholder: "client", pressure: "permits are delayed", difficulty: "Medium", traits: ["design", "constraints", "communication"], tools: ["Floor plan", "Code checklist", "Budget notes"] },
  { title: "Urban Planner", field: "Engineering", mission: "recommend a safer street redesign", focus: "community tradeoffs", stakeholder: "city council member", pressure: "residents disagree", difficulty: "Medium", traits: ["systems", "public input", "tradeoffs"], tools: ["Traffic map", "Survey results", "Policy brief"] },
  { title: "Environmental Scientist", field: "Science", mission: "interpret pollution readings for a local site", focus: "environmental evidence", stakeholder: "public health official", pressure: "the public wants answers", difficulty: "Medium", traits: ["field work", "data", "public communication"], tools: ["Sample data", "Site map", "Risk summary"] },
  { title: "Research Scientist", field: "Science", mission: "decide whether results are strong enough to publish", focus: "scientific rigor", stakeholder: "lab director", pressure: "funding depends on progress", difficulty: "High", traits: ["curiosity", "rigor", "persistence"], tools: ["Experiment log", "Peer notes", "Draft paper"] },
  { title: "Electrician", field: "Skilled Trades", mission: "trace a wiring problem safely", focus: "safety checks", stakeholder: "site manager", pressure: "the building opens tomorrow", difficulty: "Medium", traits: ["safety", "hands-on skill", "diagnosis"], tools: ["Circuit map", "Tester", "Safety checklist"] },
  { title: "Plumber", field: "Skilled Trades", mission: "repair a leak without shutting down the whole building", focus: "practical repair", stakeholder: "property manager", pressure: "water damage is spreading", difficulty: "Medium", traits: ["practical skill", "diagnosis", "customer service"], tools: ["Pipe map", "Repair kit", "Inspection camera"] },
  { title: "Chef", field: "Creative and Service", mission: "run dinner service after a supplier mistake", focus: "team timing", stakeholder: "restaurant manager", pressure: "guests are arriving", difficulty: "High", traits: ["speed", "taste", "leadership"], tools: ["Menu board", "Prep list", "Kitchen timer"] },
  { title: "Journalist", field: "Creative and Service", mission: "verify a story before publishing", focus: "truth seeking", stakeholder: "editor", pressure: "another outlet may publish first", difficulty: "High", traits: ["curiosity", "ethics", "writing"], tools: ["Source notes", "Fact check list", "Draft article"] },
  { title: "Graphic Designer", field: "Creative and Service", mission: "create a campaign visual with unclear feedback", focus: "visual communication", stakeholder: "brand manager", pressure: "the ad is due today", difficulty: "Medium", traits: ["visual taste", "iteration", "communication"], tools: ["Moodboard", "Design file", "Brand guide"] },
  { title: "Photographer", field: "Creative and Service", mission: "save a shoot when the original plan fails", focus: "composition", stakeholder: "client", pressure: "light is fading", difficulty: "Medium", traits: ["timing", "composition", "adaptability"], tools: ["Shot list", "Camera", "Lighting setup"] },
  { title: "Real Estate Agent", field: "Creative and Service", mission: "help a buyer choose between two imperfect homes", focus: "client fit", stakeholder: "buyer", pressure: "offers are due soon", difficulty: "Medium", traits: ["listening", "negotiation", "market sense"], tools: ["Listings", "Offer sheet", "Neighborhood notes"] },
  { title: "Airline Pilot", field: "Transportation", mission: "handle a weather delay while keeping passengers informed", focus: "operational safety", stakeholder: "flight dispatcher", pressure: "the schedule is tightening", difficulty: "High", traits: ["calm", "procedure", "safety"], tools: ["Flight plan", "Weather radar", "Checklist"] },
  { title: "Business Analyst", field: "Business", mission: "turn vague business needs into a clear process improvement", focus: "requirements", stakeholder: "operations manager", pressure: "teams disagree on the real problem", difficulty: "Medium", traits: ["analysis", "communication", "process thinking"], tools: ["Process map", "Requirements doc", "Stakeholder notes"] },
  { title: "Network Administrator", field: "Technology", mission: "restore a slow network before the school day starts", focus: "systems reliability", stakeholder: "IT director", pressure: "teachers cannot access online tools", difficulty: "Medium", traits: ["troubleshooting", "patience", "reliability"], tools: ["Network dashboard", "Router logs", "Ticket queue"] },
  { title: "Occupational Therapist", field: "Healthcare", mission: "help a patient adapt daily routines after an injury", focus: "functional recovery", stakeholder: "patient family", pressure: "the patient wants independence quickly", difficulty: "Medium", traits: ["empathy", "creativity", "coaching"], tools: ["Activity plan", "Assessment notes", "Adaptive equipment"] },
  { title: "Economist", field: "Science", mission: "explain how a policy change may affect families and businesses", focus: "economic reasoning", stakeholder: "policy advisor", pressure: "the public debate is heated", difficulty: "High", traits: ["modeling", "evidence", "communication"], tools: ["Economic model", "Survey data", "Policy brief"] },
  { title: "Animator", field: "Creative and Service", mission: "fix a scene that feels flat before client review", focus: "motion storytelling", stakeholder: "creative producer", pressure: "the review is this afternoon", difficulty: "Medium", traits: ["timing", "visual storytelling", "iteration"], tools: ["Storyboard", "Animation timeline", "Client notes"] },
  { title: "Event Planner", field: "Creative and Service", mission: "save an event schedule after a vendor cancels", focus: "coordination", stakeholder: "venue manager", pressure: "guests arrive in four hours", difficulty: "High", traits: ["organization", "calm", "negotiation"], tools: ["Run of show", "Vendor list", "Budget tracker"] }
];

const careers = baseCareers.map((career, index) => ({
  ...career,
  id: slugify(career.title),
  rank: index + 1
}));

const skillNames = ["clarity", "empathy", "execution", "ethics"];
const skillLabels = {
  clarity: "Clarity",
  empathy: "Empathy",
  execution: "Execution",
  ethics: "Ethics"
};

const times = ["9:00 AM", "10:10 AM", "11:45 AM", "1:35 PM", "3:20 PM", "5:10 PM"];

const defaultProfile = {
  traits: ["systems", "people"],
  decisionStyle: "balanced",
  playMode: "Realistic"
};

const defaultAccount = {
  name: "",
  email: "",
  role: "student",
  plan: "Free"
};

const flagshipCareerIds = [
  "software-engineer",
  "doctor",
  "teacher",
  "data-analyst",
  "ux-designer",
  "product-manager",
  "lawyer",
  "entrepreneur",
  "cybersecurity-analyst",
  "registered-nurse"
];

const planCatalog = [
  {
    name: "Free",
    price: "$0",
    audience: "Students trying SkillRova",
    features: ["3 starter simulations", "Basic fit report", "Local progress history"]
  },
  {
    name: "Pro",
    price: "$9/mo",
    audience: "Families and serious learners",
    features: ["All flagship simulations", "Advanced reports", "Career comparison history"]
  },
  {
    name: "School",
    price: "Custom",
    audience: "Counselors, schools, and programs",
    features: ["Classroom dashboard", "Exportable summaries", "Cohort guidance workflow"]
  }
];

const playModes = {
  Beginner: {
    label: "Beginner guidance",
    energyStart: 92,
    stressStart: 8,
    energyMultiplier: 0.72,
    stressMultiplier: 0.68,
    scoreBonus: 1,
    hint: "Guidance mode shows more context and is forgiving about energy."
  },
  Realistic: {
    label: "Realistic pressure",
    energyStart: 85,
    stressStart: 15,
    energyMultiplier: 1,
    stressMultiplier: 1,
    scoreBonus: 0,
    hint: "Realistic mode uses normal workday pressure and tradeoffs."
  },
  Challenge: {
    label: "Challenge mode",
    energyStart: 76,
    stressStart: 24,
    energyMultiplier: 1.18,
    stressMultiplier: 1.3,
    scoreBonus: -1,
    hint: "Challenge mode adds pressure and rewards disciplined choices."
  }
};

const traitCareerSignals = {
  people: ["empathy", "communication", "listening", "guidance", "negotiation", "coaching", "patient communication", "advocacy"],
  systems: ["logic", "systems thinking", "data", "modeling", "requirements", "process thinking", "financial judgment", "debugging"],
  creative: ["creativity", "visual thinking", "visual taste", "storytelling", "composition", "design", "motion storytelling"],
  "hands-on": ["hands-on skill", "practical skill", "field work", "body mechanics", "procedure", "repair", "safety checks"],
  service: ["care", "service", "patient care", "public value", "empathy", "advocacy", "instruction"],
  risk: ["calm", "risk thinking", "operational safety", "courage", "discipline", "fast pressure", "judgment"]
};

const fieldBlueprints = {
  Technology: { system: "Product system", signal: "Logs and usage", stakes: "Users blocked", environment: "Digital operations room", accent: "#4f8cff", secondary: "#20c997" },
  Design: { system: "Experience map", signal: "Research evidence", stakes: "Confused users", environment: "Prototype studio", accent: "#d266ff", secondary: "#ff8f5a" },
  Business: { system: "Operating plan", signal: "Budget and demand", stakes: "Revenue tradeoff", environment: "Strategy floor", accent: "#f5b84b", secondary: "#4f8cff" },
  Healthcare: { system: "Care pathway", signal: "Clinical evidence", stakes: "Patient safety", environment: "Care command desk", accent: "#20c997", secondary: "#ff6b6b" },
  "Social Impact": { system: "Support network", signal: "Case signals", stakes: "Trust and safety", environment: "Community response hub", accent: "#20c997", secondary: "#7b61ff" },
  Education: { system: "Learning plan", signal: "Student evidence", stakes: "Understanding gap", environment: "Classroom control board", accent: "#f5b84b", secondary: "#20c997" },
  "Law and Public Service": { system: "Public trust", signal: "Policy and facts", stakes: "Rights and risk", environment: "Civic decision room", accent: "#4f8cff", secondary: "#f5b84b" },
  Engineering: { system: "Design system", signal: "Test evidence", stakes: "Safety and cost", environment: "Engineering lab", accent: "#20c997", secondary: "#f5b84b" },
  Science: { system: "Evidence model", signal: "Data quality", stakes: "Scientific confidence", environment: "Research station", accent: "#4f8cff", secondary: "#20c997" },
  "Skilled Trades": { system: "Site conditions", signal: "Diagnostic checks", stakes: "Safety and uptime", environment: "Field service bay", accent: "#f5b84b", secondary: "#ff8f5a" },
  "Creative and Service": { system: "Guest experience", signal: "Client feedback", stakes: "Quality under time", environment: "Service studio", accent: "#d266ff", secondary: "#f5b84b" },
  Transportation: { system: "Operations route", signal: "Weather and timing", stakes: "Safety margin", environment: "Operations cockpit", accent: "#4f8cff", secondary: "#ff6b6b" }
};

const eventArtifactLabels = {
  "Morning brief": ["Situation board", "Priority signal", "Hidden constraint"],
  Inbox: ["Stakeholder message", "Risk flag", "Reply goal"],
  Meeting: ["Room tension", "Decision rule", "Agreement gap"],
  "Task board": ["Must finish", "Can cut", "Owner needed"],
  Crisis: ["Late signal", "Damage risk", "Fastest check"],
  "Wrap-up": ["Decision recap", "Next owner", "Open risk"],
  "Chart update": ["New evidence", "Confidence level", "Patient concern"],
  Consult: ["Expert split", "Safety check", "Cost pressure"],
  "Client call": ["Client goal", "Legal risk", "Useful answer"],
  "Code review": ["Shortcut", "Failure path", "Test gap"],
  Classroom: ["Misconception", "Ready group", "Support need"],
  Critique: ["Feedback conflict", "User evidence", "Build cost"],
  Prototype: ["Test target", "Learning goal", "Time limit"],
  Analysis: ["Data gap", "False lead", "Confidence note"],
  "Customer call": ["Customer pain", "Churn risk", "Recovery option"]
};

const arenaActions = [
  {
    id: "scan",
    label: "Check facts",
    detail: "Look for what matters.",
    effects: { evidence: 14, focus: 4, energy: -3, stress: -1, clarity: 1, ethics: 1 }
  },
  {
    id: "talk",
    label: "Ask someone",
    detail: "Understand their concern.",
    effects: { trust: 13, focus: 2, energy: -4, stress: -2, empathy: 1, clarity: 1 }
  },
  {
    id: "build",
    label: "Do the work",
    detail: "Make progress now.",
    effects: { momentum: 16, focus: -2, energy: -7, stress: 3, execution: 2 }
  },
  {
    id: "reset",
    label: "Take a breath",
    detail: "Calm the situation.",
    effects: { focus: 15, stress: -6, energy: -2, empathy: 1 }
  }
];

const achievementCatalog = [
  { id: "first-day", title: "First Workday", description: "Complete your first career simulation.", check: (runs) => runs.length >= 1 },
  { id: "explorer", title: "Career Explorer", description: "Complete five different careers.", check: (runs) => new Set(runs.map((run) => run.careerId)).size >= 5 },
  { id: "clear-communicator", title: "Clear Communicator", description: "Score 10 or more in clarity.", check: (runs) => runs.some((run) => run.scores?.clarity >= 10) },
  { id: "calm-pressure", title: "Calm Under Pressure", description: "Finish with stress under 35 in Realistic or Challenge mode.", check: (runs) => runs.some((run) => run.stress < 35 && run.playMode !== "Beginner") },
  { id: "ethical-decision-maker", title: "Ethical Decision Maker", description: "Score 10 or more in ethics.", check: (runs) => runs.some((run) => run.scores?.ethics >= 10) },
  { id: "systems-thinker", title: "Systems Thinker", description: "Complete three Technology, Engineering, Science, or Business roles.", check: (runs) => runs.filter((run) => ["Technology", "Engineering", "Science", "Business"].includes(getCareer(run.careerId).field)).length >= 3 },
  { id: "helper", title: "People Helper", description: "Complete three Education, Healthcare, or Social Impact roles.", check: (runs) => runs.filter((run) => ["Education", "Healthcare", "Social Impact"].includes(getCareer(run.careerId).field)).length >= 3 }
];

const app = {
  view: "dashboard",
  selectedCareerId: null,
  activeTab: "inbox",
  sim: null,
  progress: loadProgress(),
  lastReport: null,
  animationFrame: null,
  pulse: 0,
  eventTimer: null
};

const dom = {
  navButtons: document.querySelectorAll(".nav-btn"),
  views: document.querySelectorAll(".view"),
  viewJumps: document.querySelectorAll("[data-view-jump]"),
  startFeaturedBtn: document.querySelector("#startFeaturedBtn"),
  dashboardCareerCount: document.querySelector("#dashboardCareerCount"),
  dashboardRunCount: document.querySelector("#dashboardRunCount"),
  dashboardBestFit: document.querySelector("#dashboardBestFit"),
  dashboardRecommendations: document.querySelector("#dashboardRecommendations"),
  profileRecommendations: document.querySelector("#profileRecommendations"),
  saveProfileBtn: document.querySelector("#saveProfileBtn"),
  resetProfileBtn: document.querySelector("#resetProfileBtn"),
  profileTraitInputs: document.querySelectorAll("input[name='profileTrait']"),
  decisionStyleInputs: document.querySelectorAll("input[name='decisionStyle']"),
  playModeInputs: document.querySelectorAll("input[name='playMode']"),
  careerSearch: document.querySelector("#careerSearch"),
  fieldFilter: document.querySelector("#fieldFilter"),
  difficultyFilter: document.querySelector("#difficultyFilter"),
  sortSelect: document.querySelector("#sortSelect"),
  playModeSelect: document.querySelector("#playModeSelect"),
  careerCount: document.querySelector("#careerCount"),
  filterSummary: document.querySelector("#filterSummary"),
  careerGrid: document.querySelector("#careerGrid"),
  careerDetail: document.querySelector("#careerDetail"),
  simField: document.querySelector("#simField"),
  simTitle: document.querySelector("#simTitle"),
  simMission: document.querySelector("#simMission"),
  exitSimBtn: document.querySelector("#exitSimBtn"),
  restartSimBtn: document.querySelector("#restartSimBtn"),
  timeLabel: document.querySelector("#timeLabel"),
  energyLabel: document.querySelector("#energyLabel"),
  stressLabel: document.querySelector("#stressLabel"),
  progressLabel: document.querySelector("#progressLabel"),
  gameObjective: document.querySelector("#gameObjective"),
  clockRing: document.querySelector("#clockRing"),
  clockText: document.querySelector("#clockText"),
  liveAlerts: document.querySelector("#liveAlerts"),
  objectiveList: document.querySelector("#objectiveList"),
  sceneTaskTitle: document.querySelector("#sceneTaskTitle"),
  sceneTaskProgress: document.querySelector("#sceneTaskProgress"),
  arenaStats: document.querySelector("#arenaStats"),
  arenaActions: document.querySelector("#arenaActions"),
  simStageLabel: document.querySelector("#simStageLabel"),
  simStageTitle: document.querySelector("#simStageTitle"),
  simStagePulse: document.querySelector("#simStagePulse"),
  simCanvas: document.querySelector("#simCanvas"),
  simWorldMap: document.querySelector("#simWorldMap"),
  decisionIntel: document.querySelector("#decisionIntel"),
  timeline: document.querySelector("#timeline"),
  eventChannel: document.querySelector("#eventChannel"),
  eventStep: document.querySelector("#eventStep"),
  eventTitle: document.querySelector("#eventTitle"),
  eventBody: document.querySelector("#eventBody"),
  eventArtifacts: document.querySelector("#eventArtifacts"),
  choiceList: document.querySelector("#choiceList"),
  consequenceBox: document.querySelector("#consequenceBox"),
  tabButtons: document.querySelectorAll(".tab-btn"),
  workspaceFeed: document.querySelector("#workspaceFeed"),
  skillMeters: document.querySelector("#skillMeters"),
  decisionLog: document.querySelector("#decisionLog"),
  historyList: document.querySelector("#historyList"),
  recommendationList: document.querySelector("#recommendationList"),
  achievementList: document.querySelector("#achievementList"),
  exportProgressBtn: document.querySelector("#exportProgressBtn"),
  clearProgressBtn: document.querySelector("#clearProgressBtn"),
  exportClassroomBtn: document.querySelector("#exportClassroomBtn"),
  classroomMetrics: document.querySelector("#classroomMetrics"),
  classroomInsights: document.querySelector("#classroomInsights"),
  planGrid: document.querySelector("#planGrid"),
  accountName: document.querySelector("#accountName"),
  accountEmail: document.querySelector("#accountEmail"),
  accountRoleInputs: document.querySelectorAll("input[name='accountRole']"),
  accountPlanInputs: document.querySelectorAll("input[name='accountPlan']"),
  saveAccountBtn: document.querySelector("#saveAccountBtn"),
  accountStatusTitle: document.querySelector("#accountStatusTitle"),
  accountStatus: document.querySelector("#accountStatus"),
  reportModal: document.querySelector("#reportModal"),
  reportTitle: document.querySelector("#reportTitle"),
  reportSummary: document.querySelector("#reportSummary"),
  reportStats: document.querySelector("#reportStats"),
  achievementUnlocks: document.querySelector("#achievementUnlocks"),
  reflectionList: document.querySelector("#reflectionList"),
  tryRecommendedBtn: document.querySelector("#tryRecommendedBtn"),
  downloadReportBtn: document.querySelector("#downloadReportBtn"),
  backToLibraryBtn: document.querySelector("#backToLibraryBtn"),
  closeReportBtn: document.querySelector("#closeReportBtn")
};

function slugify(text) {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function loadProgress() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY) || LEGACY_STORAGE_KEYS.map((key) => localStorage.getItem(key)).find(Boolean);
    if (!stored) return { runs: [], profile: { ...defaultProfile }, account: { ...defaultAccount } };
    const parsed = JSON.parse(stored);
    return {
      runs: Array.isArray(parsed.runs) ? parsed.runs : [],
      profile: normalizeProfile(parsed.profile),
      account: normalizeAccount(parsed.account)
    };
  } catch {
    return { runs: [], profile: { ...defaultProfile }, account: { ...defaultAccount } };
  }
}

function saveProgress() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(app.progress));
  syncProgressToServer();
}

function syncProgressToServer() {
  if (!window.location.protocol.startsWith("http") || typeof fetch !== "function") return;
  const account = normalizeAccount(app.progress.account);
  const learnerId = account.email || account.name || "demo";
  fetch("/api/progress", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ learnerId, ...app.progress, account })
  }).catch(() => {
    // Local storage remains the source of truth if the optional server is unavailable.
  });
}

function normalizeProfile(profile = {}) {
  const traits = Array.isArray(profile.traits) && profile.traits.length
    ? profile.traits.filter((trait) => traitCareerSignals[trait])
    : defaultProfile.traits;
  const decisionStyle = ["careful", "balanced", "fast"].includes(profile.decisionStyle)
    ? profile.decisionStyle
    : defaultProfile.decisionStyle;
  const playMode = playModes[profile.playMode] ? profile.playMode : defaultProfile.playMode;
  return { traits, decisionStyle, playMode };
}

function normalizeAccount(account = {}) {
  const role = ["student", "parent", "counselor"].includes(account.role) ? account.role : defaultAccount.role;
  const plan = planCatalog.some((item) => item.name === account.plan) ? account.plan : defaultAccount.plan;
  return {
    name: typeof account.name === "string" ? account.name.slice(0, 80) : defaultAccount.name,
    email: typeof account.email === "string" ? account.email.slice(0, 120) : defaultAccount.email,
    role,
    plan
  };
}

function getProfile() {
  app.progress.profile = normalizeProfile(app.progress.profile);
  return app.progress.profile;
}

function getPlayMode() {
  return playModes[getProfile().playMode];
}

function switchView(view) {
  app.view = view;
  if (view !== "simulation") {
    stopSimulationAnimation();
    stopEventClock();
  }
  dom.views.forEach((section) => {
    section.classList.toggle("active-view", section.id === `${view}View`);
  });
  dom.navButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.view === view);
  });
  renderDashboard();
  if (view === "profile") renderProfile();
  if (view === "library") renderLibrary();
  if (view === "progress") renderProgress();
  if (view === "classroom") renderClassroom();
  if (view === "plans") renderPlans();
  if (view === "account") renderAccount();
}

function stopSimulationAnimation() {
  if (app.animationFrame && typeof cancelAnimationFrame === "function") {
    cancelAnimationFrame(app.animationFrame);
  }
  app.animationFrame = null;
}

function getCareer(id) {
  return careers.find((career) => career.id === id) || careers[0];
}

function getCareerRuns(careerId) {
  return app.progress.runs.filter((run) => run.careerId === careerId);
}

function getBestRun(careerId) {
  return getCareerRuns(careerId).sort((a, b) => b.fitScore - a.fitScore)[0];
}

function getCareerMatchScore(career) {
  const profile = getProfile();
  const careerText = [
    career.title,
    career.field,
    career.focus,
    career.traits.join(" "),
    career.mission
  ].join(" ").toLowerCase();
  let score = 0;

  profile.traits.forEach((trait) => {
    traitCareerSignals[trait].forEach((signal) => {
      if (careerText.includes(signal.toLowerCase())) score += 9;
    });
  });

  if (profile.decisionStyle === "careful" && ["Science", "Healthcare", "Law and Public Service", "Business"].includes(career.field)) score += 8;
  if (profile.decisionStyle === "fast" && ["Transportation", "Skilled Trades", "Creative and Service"].includes(career.field)) score += 8;
  if (profile.decisionStyle === "balanced" && ["Technology", "Education", "Engineering", "Business"].includes(career.field)) score += 6;

  const best = getBestRun(career.id);
  if (best) score += Math.round(best.fitScore / 12);
  return score;
}

function getProfileRecommendations(limit = 5) {
  const played = new Set(app.progress.runs.map((run) => run.careerId));
  return [...careers]
    .sort((a, b) => {
      const playedDelta = Number(played.has(a.id)) - Number(played.has(b.id));
      if (playedDelta !== 0) return playedDelta;
      return getCareerMatchScore(b) - getCareerMatchScore(a) || a.rank - b.rank;
    })
    .slice(0, limit);
}

function uniqueFields() {
  return [...new Set(careers.map((career) => career.field))].sort();
}

function renderFilters() {
  uniqueFields().forEach((field) => {
    const option = document.createElement("option");
    option.value = field;
    option.textContent = field;
    dom.fieldFilter.appendChild(option);
  });
}

function getFilteredCareers() {
  const query = dom.careerSearch.value.trim().toLowerCase();
  const field = dom.fieldFilter.value;
  const difficulty = dom.difficultyFilter.value;
  const sort = dom.sortSelect.value;

  const filtered = careers.filter((career) => {
    const text = [
      career.title,
      career.field,
      career.mission,
      career.focus,
      career.stakeholder,
      career.traits.join(" ")
    ].join(" ").toLowerCase();
    return (
      text.includes(query) &&
      (field === "all" || career.field === field) &&
      (difficulty === "all" || career.difficulty === difficulty)
    );
  });

  if (sort === "title") return filtered.sort((a, b) => a.title.localeCompare(b.title));
  if (sort === "field") return filtered.sort((a, b) => a.field.localeCompare(b.field) || a.title.localeCompare(b.title));
  return filtered.sort((a, b) => {
    const flagshipDelta = Number(flagshipCareerIds.includes(b.id)) - Number(flagshipCareerIds.includes(a.id));
    if (flagshipDelta !== 0) return flagshipDelta;
    const aPlayed = getCareerRuns(a.id).length;
    const bPlayed = getCareerRuns(b.id).length;
    if (aPlayed !== bPlayed) return aPlayed - bPlayed;
    return getCareerMatchScore(b) - getCareerMatchScore(a) || a.rank - b.rank;
  });
}

function renderDashboard() {
  const best = [...app.progress.runs].sort((a, b) => b.fitScore - a.fitScore)[0];
  dom.dashboardCareerCount.textContent = careers.length;
  dom.dashboardRunCount.textContent = app.progress.runs.length;
  dom.dashboardBestFit.textContent = best ? getCareer(best.careerId).title : "None";
  renderRecommendationCards(dom.dashboardRecommendations, getProfileRecommendations(3));
}

function isFlagshipCareer(career) {
  return flagshipCareerIds.includes(career.id);
}

function renderProfile() {
  const profile = getProfile();
  dom.profileTraitInputs.forEach((input) => {
    input.checked = profile.traits.includes(input.value);
  });
  dom.decisionStyleInputs.forEach((input) => {
    input.checked = input.value === profile.decisionStyle;
  });
  dom.playModeInputs.forEach((input) => {
    input.checked = input.value === profile.playMode;
  });
  renderRecommendationCards(dom.profileRecommendations, getProfileRecommendations(5));
}

function saveProfileFromForm() {
  const traits = [...dom.profileTraitInputs].filter((input) => input.checked).map((input) => input.value);
  const decisionStyle = [...dom.decisionStyleInputs].find((input) => input.checked)?.value || defaultProfile.decisionStyle;
  const playMode = [...dom.playModeInputs].find((input) => input.checked)?.value || defaultProfile.playMode;
  app.progress.profile = normalizeProfile({ traits, decisionStyle, playMode });
  dom.playModeSelect.value = app.progress.profile.playMode;
  saveProgress();
  renderProfile();
  renderDashboard();
  renderLibrary();
}

function renderRecommendationCards(container, list) {
  if (!container) return;
  container.innerHTML = list.map((career) => `
    <article class="recommendation-card">
      <strong>${escapeHtml(career.title)}</strong>
      <span>${escapeHtml(career.field)} - ${escapeHtml(career.focus)} - match ${getCareerMatchScore(career)}</span>
      <button class="primary-btn" type="button" data-start="${career.id}">Start</button>
    </article>
  `).join("");
}

function renderLibrary() {
  dom.playModeSelect.value = getProfile().playMode;
  const filtered = getFilteredCareers();
  const query = dom.careerSearch.value.trim();
  dom.careerCount.textContent = `${filtered.length} careers`;
  dom.filterSummary.textContent = query ? `Search: ${query}` : "Showing all matching careers";
  dom.careerGrid.innerHTML = "";

  filtered.forEach((career) => {
    const best = getBestRun(career.id);
    const match = Math.max(0, Math.min(100, getCareerMatchScore(career)));
    const blueprint = getCareerBlueprint(career);
    const card = document.createElement("article");
    card.className = `career-card ${career.id === app.selectedCareerId ? "active" : ""}`;
    card.style.setProperty("--field-accent", blueprint.accent || "#4f8cff");
    card.innerHTML = `
      <div>
        <div class="career-card-head">
          <div class="career-orb" aria-hidden="true">${escapeHtml(getCareerInitials(career.title))}</div>
          <div class="tag-row">
            <span class="tag">${escapeHtml(career.field)}</span>
            <span class="tag green">${escapeHtml(career.difficulty)}</span>
            <span class="tag">${getCareerScenarioPack(career).authored ? "Authored" : "Adaptive"}</span>
            ${isFlagshipCareer(career) ? `<span class="tag gold">Flagship</span>` : ""}
          </div>
        </div>
        <h3>${escapeHtml(career.title)}</h3>
        <p>${escapeHtml(sentenceCase(career.mission))} while dealing with ${escapeHtml(career.pressure)}.</p>
      </div>
      <div>
        <div class="match-strip">
          <span>Profile match</span>
          <strong>${match}</strong>
          <i style="width: ${match}%"></i>
        </div>
        <div class="tag-row">
          ${best ? `<span class="tag gold">Best fit ${best.fitScore}</span>` : ""}
          ${career.traits.map((trait) => `<span class="tag">${escapeHtml(trait)}</span>`).join("")}
        </div>
        <div class="card-actions">
          <button class="secondary-btn" type="button" data-preview="${career.id}">Preview</button>
          <button class="primary-btn" type="button" data-start="${career.id}">Start</button>
        </div>
      </div>
    `;
    dom.careerGrid.appendChild(card);
  });

  if (app.selectedCareerId && filtered.some((career) => career.id === app.selectedCareerId)) {
    renderCareerDetail(getCareer(app.selectedCareerId));
  } else {
    app.selectedCareerId = null;
    renderEmptyCareerDetail();
  }
}

function getCareerInitials(title) {
  return title
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

function renderEmptyCareerDetail() {
  dom.careerDetail.innerHTML = `
    <p class="eyebrow">Choose first</p>
    <h2>Select a career</h2>
    <p>Preview any role in the library to see the mission, pressure, tools, skills, and scenario depth before starting.</p>
    <div class="detail-list">
      <div><strong>No default role</strong><span>The simulator waits for the student to choose a career.</span></div>
      <div><strong>Tip</strong><span>Use the profile page for personalized recommendations, or browse all careers manually.</span></div>
    </div>
  `;
}

function sentenceCase(text) {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function renderCareerDetail(career) {
  const best = getBestRun(career.id);
  dom.careerDetail.innerHTML = `
    <p class="eyebrow">Career preview</p>
    <h2>${escapeHtml(career.title)}</h2>
    <p>${escapeHtml(sentenceCase(career.mission))}. The day tests ${escapeHtml(career.focus)} while ${escapeHtml(career.pressure)}.</p>
    <div class="detail-list">
      <div><strong>Typical pressure</strong><span>${escapeHtml(career.pressure)}</span></div>
      <div><strong>Main stakeholder</strong><span>${escapeHtml(sentenceCase(career.stakeholder))}</span></div>
      <div><strong>Tools in the simulation</strong><span>${escapeHtml(career.tools.join(", "))}</span></div>
      <div><strong>Skills practiced</strong><span>${escapeHtml(career.traits.join(", "))}</span></div>
      <div><strong>Scenario depth</strong><span>${getCareerScenarioPack(career).authored ? "Deep authored scenario pack with role-specific pressure." : "Adaptive scenario generated from this role's mission and tools."}</span></div>
      <div><strong>Play mode</strong><span>${escapeHtml(playModes[getProfile().playMode].label)}. ${escapeHtml(playModes[getProfile().playMode].hint)}</span></div>
      <div><strong>Your history</strong><span>${best ? `Best fit score: ${best.fitScore}. Completed ${getCareerRuns(career.id).length} time(s).` : "Not played yet."}</span></div>
    </div>
    <button class="primary-btn" type="button" data-start="${career.id}">Start this workday</button>
  `;
}

const authoredScenarioPacks = {
  "product-manager": [
    ["Morning brief", "Launch scope is breaking", "Engineering says the release is too large. Sales says the biggest customer expects one more feature. Design says the flow still confuses new users.", "scope"],
    ["Inbox", "Leadership wants a launch call", "Your manager asks whether to ship Friday, delay two weeks, or cut scope. Each option has a cost.", "alignment"],
    ["Meeting", "Design and engineering disagree", "Design wants more research. Engineering wants a smaller build. Sales wants the customer feature. You need to turn disagreement into a decision.", "tradeoff"],
    ["Task board", "Prioritize the release", "You have six work items and time for three. The decision will signal what kind of product leader you are.", "scope"],
    ["Crisis", "A usage metric changes", "Analytics shows new users are dropping before activation. The launch plan may solve the wrong problem.", "evidence"],
    ["Wrap-up", "Send the product decision", "Everyone needs a clear product call, the reason behind it, and what changes tomorrow.", "recap"]
  ],
  "software-engineer": [
    ["Morning brief", "Production bug report", "A payment bug affects a small but important group of users. The logs are noisy and the rollback may break another fix.", "evidence"],
    ["Inbox", "Product asks for an estimate", "The product manager wants to know if the fix ships today. You only understand half the failure path.", "alignment"],
    ["Code review", "A teammate suggests a shortcut", "The shortcut works in the obvious case, but it may hide the real source of the bug.", "ethics"],
    ["Task board", "Test coverage is thin", "The deadline is close. You can patch quickly, write a targeted test, or ask for more time.", "scope"],
    ["Crisis", "The fix fails in staging", "The bug is deeper than expected. Support is waiting for a customer update.", "evidence"],
    ["Wrap-up", "Write the engineering handoff", "The team needs the root cause, fix status, test plan, and remaining risk.", "recap"]
  ],
  "doctor": [
    ["Morning brief", "Unclear symptoms", "A patient has overlapping symptoms and incomplete history. The waiting room is full, but the next step matters.", "ethics"],
    ["Chart update", "A lab result is borderline", "The result could be harmless or a warning sign. The patient is anxious and wants certainty.", "evidence"],
    ["Consult", "Team opinions split", "A colleague recommends watchful waiting. Another wants more tests. You need to balance safety, cost, and anxiety.", "tradeoff"],
    ["Task board", "Triage pressure builds", "Two other patients need attention. You must decide what cannot wait.", "scope"],
    ["Crisis", "New symptom appears", "The patient's condition changes slightly. It may be important, or it may be noise.", "ethics"],
    ["Wrap-up", "Explain the care plan", "The patient needs a plain-English plan, warning signs, and next steps.", "recap"]
  ],
  "lawyer": [
    ["Morning brief", "Client deadline", "A client needs advice before signing a risky agreement. The facts are incomplete and the other side is pushing.", "ethics"],
    ["Inbox", "New document arrives", "A late clause changes the risk. It is subtle, but it could matter later.", "evidence"],
    ["Client call", "The client wants confidence", "The client asks, 'Can I sign this today?' You need to be useful without overstating certainty.", "alignment"],
    ["Task board", "Prepare the memo", "You can write a short practical answer, research more, or escalate to a specialist.", "scope"],
    ["Crisis", "A hidden conflict appears", "You notice a possible conflict between the client's goal and another obligation.", "ethics"],
    ["Wrap-up", "Send the legal advice", "The client needs options, risks, and a recommended next step.", "recap"]
  ],
  "teacher": [
    ["Morning brief", "The class is stuck", "Students did poorly on yesterday's exit ticket. A quiz is tomorrow, and the planned lesson may not work.", "empathy"],
    ["Inbox", "Parent message", "A parent says their child feels lost and embarrassed to ask questions in class.", "alignment"],
    ["Classroom", "Misconceptions surface", "Several students are making the same mistake, but a few are ready to move ahead.", "tradeoff"],
    ["Task board", "Rethink the lesson", "You can reteach, split groups, or continue so the schedule stays intact.", "scope"],
    ["Crisis", "Behavior derails the room", "A frustrated student interrupts the activity. The rest of the class is watching.", "empathy"],
    ["Wrap-up", "Plan tomorrow's quiz support", "Students need clarity on what to practice and how to recover.", "recap"]
  ],
  "entrepreneur": [
    ["Morning brief", "Cash is tight", "You have enough runway for one serious bet. A customer wants a feature, but marketing needs money too.", "scope"],
    ["Inbox", "Investor asks for traction", "An investor wants proof that people care. Your numbers are promising but early.", "evidence"],
    ["Customer call", "A customer complains", "The first paying customer is unhappy and might churn unless you respond well.", "empathy"],
    ["Task board", "Choose the week's focus", "You can sell, build, interview users, or improve onboarding. You cannot do all four.", "tradeoff"],
    ["Crisis", "A competitor launches", "A competitor announces a similar product. The team is worried.", "alignment"],
    ["Wrap-up", "Send the founder update", "Your team needs a simple direction, confidence, and honest risks.", "recap"]
  ],
  "ux-designer": [
    ["Morning brief", "Users are confused", "Research clips show users missing the main action. The team wants design changes by tomorrow.", "empathy"],
    ["Inbox", "Stakeholder wants polish", "A stakeholder asks for visual polish, but the bigger issue may be the flow itself.", "tradeoff"],
    ["Critique", "Feedback conflicts", "Product wants fewer steps. Support wants more explanation. Engineering wants minimal changes.", "alignment"],
    ["Prototype", "Choose what to test", "You can test copy, layout, navigation, or the entire journey. Time is limited.", "scope"],
    ["Crisis", "A test participant fails", "A participant gets stuck in a way nobody expected.", "evidence"],
    ["Wrap-up", "Share design rationale", "The team needs to understand what changed, why, and what still needs validation.", "recap"]
  ],
  "data-analyst": [
    ["Morning brief", "Metric dropped overnight", "A key activation metric fell by 12 percent. Leadership wants an answer today.", "evidence"],
    ["Inbox", "Growth team has a theory", "Growth thinks a campaign brought lower-quality users. Product suspects a recent UI change.", "alignment"],
    ["Analysis", "Data is incomplete", "One table is delayed and another has a tracking gap. You can still find useful signals.", "ethics"],
    ["Task board", "Choose the analysis path", "You can segment users, inspect funnels, compare cohorts, or wait for cleaner data.", "scope"],
    ["Crisis", "The first chart misleads", "A quick chart points to the wrong cause until you notice a denominator problem.", "evidence"],
    ["Wrap-up", "Present the finding", "Leadership needs the likely cause, confidence level, and next measurement step.", "recap"]
  ]
};

function getCareerScenarioPack(career) {
  const events = authoredScenarioPacks[career.id];
  return { authored: Boolean(events), events };
}

function buildScenario(career, variant = 0) {
  const pack = getCareerScenarioPack(career);
  if (pack.authored) {
    return pack.events.map(([channel, title, body, choiceType], index) => ({
      time: times[index],
      channel,
      title,
      body,
      choices: getChoiceSet(choiceType, career, variant)
    })).map((event, index, events) => enrichScenarioEvent(event, career, index, events.length));
  }

  const genericOpeners = [
    `You need to ${career.mission}. The first update is already messy: ${career.pressure}.`,
    `The day starts with a priority conflict. You need to ${career.mission}, but ${career.pressure}.`,
    `A routine morning turns complicated. Your goal is to ${career.mission}, and ${career.pressure}.`
  ];
  const shared = { careerTitle: career.title, focus: career.focus };
  return [
    {
      time: times[0],
      channel: "Morning brief",
      title: `Your day as a ${career.title} begins`,
      body: `${genericOpeners[variant % genericOpeners.length]} Your ${career.stakeholder} wants a direction before the next checkpoint.`,
      choices: [
        choice("Map the decision before acting", "List the goal, facts, unknowns, and the risk of waiting.", { clarity: 3, empathy: 1, execution: 1, ethics: 1 }, -7, 2, "You slow the room down just enough to make the problem concrete."),
        choice("Jump straight to the fastest answer", "Pick the option that appears quickest and promise to adjust later.", { clarity: 0, empathy: 0, execution: 2, ethics: -1 }, -4, 6, "The day moves, but several people are not sure why this path is right."),
        choice("Ask everyone to send more context", "Delay the call until every stakeholder adds more detail.", { clarity: 1, empathy: 1, execution: -1, ethics: 1 }, -5, 4, "You get better context, but momentum drops and the deadline feels tighter.")
      ]
    },
    {
      time: times[1],
      channel: "Inbox",
      title: `A stakeholder pushes back`,
      body: `A message from the ${career.stakeholder} says your plan may create a new problem. You have limited time to respond without creating confusion.`,
      choices: [
        choice("Reply with the tradeoff and a recommendation", "Explain what you are optimizing for and what risk you accept.", { clarity: 3, empathy: 1, execution: 2, ethics: 1 }, -8, 3, "The reply gives people something clear to react to."),
        choice("Reassure them that it will be fine", "Keep the message positive without going into detail.", { clarity: -1, empathy: 1, execution: 1, ethics: -1 }, -3, 5, "The tone is friendly, but the concern remains unresolved."),
        choice("Schedule a quick decision call", "Bring the right people together for a ten-minute alignment check.", { clarity: 1, empathy: 2, execution: 1, ethics: 1 }, -9, 2, "The call costs energy, but it prevents private confusion from spreading.")
      ]
    },
    {
      time: times[2],
      channel: "Meeting",
      title: `The team disagrees about ${career.focus}`,
      body: `One person wants speed. Another wants quality. Someone else worries about fairness, safety, or cost. There is no perfect option.`,
      choices: [
        choice("Name the real tension", "Say what each side is protecting before choosing a path.", { clarity: 2, empathy: 3, execution: 1, ethics: 2 }, -9, 3, "People feel heard, and the decision becomes less personal."),
        choice("Back the loudest opinion", "Choose the option with the strongest voice in the room.", { clarity: -1, empathy: -1, execution: 2, ethics: -2 }, -4, 8, "The meeting ends quickly, but trust takes a hit."),
        choice("Use a small test to reduce uncertainty", "Create a quick check using the best available evidence.", { clarity: 2, empathy: 1, execution: 2, ethics: 1 }, -10, 2, "You avoid guessing and create a stronger basis for action.")
      ]
    },
    {
      time: times[3],
      channel: "Task board",
      title: "The work is bigger than the time available",
      body: `Your task list has more work than the day can hold. To finish well, you need to decide what matters most and what can wait.`,
      choices: [
        choice("Protect the most important outcome", "Cut lower-value work and defend the core goal.", { clarity: 2, empathy: 0, execution: 3, ethics: 1 }, -10, 4, "The plan becomes smaller and more realistic."),
        choice("Try to do everything", "Push through the full list and hope quality holds.", { clarity: -1, empathy: 0, execution: -1, ethics: -1 }, -18, 12, "The effort is intense, but rushed work creates new risk."),
        choice("Negotiate scope with evidence", "Show what can fit, what cannot, and why.", { clarity: 3, empathy: 2, execution: 2, ethics: 1 }, -11, 3, "The conversation is harder, but the plan becomes believable.")
      ]
    },
    {
      time: times[4],
      channel: "Crisis",
      title: "A late surprise changes the day",
      body: `New information arrives: ${career.pressure}. Your earlier plan may still work, but only if you adapt quickly and communicate clearly.`,
      choices: [
        choice("Pause and re-check the highest risk", "Find the one risk that could make the decision harmful or useless.", { clarity: 2, empathy: 0, execution: 1, ethics: 3 }, -8, 2, "You catch the part of the plan that could have caused the biggest issue."),
        choice("Keep going so the deadline is not missed", "Stay on the original path and avoid more debate.", { clarity: 0, empathy: -1, execution: 2, ethics: -2 }, -6, 9, "You preserve speed, but the late signal is not fully handled."),
        choice("Ask for help from the strongest expert", "Bring in one person who can quickly judge the risk.", { clarity: 1, empathy: 2, execution: 2, ethics: 2 }, -9, 3, "You use the team well and avoid pretending to know everything.")
      ]
    },
    {
      time: times[5],
      channel: "Wrap-up",
      title: "Send the end-of-day update",
      body: `The day is almost over. People need to know what happened, what decision was made, what changed, and what happens next.`,
      choices: [
        choice("Send a clear recap with owners", "Explain the decision, reason, tradeoffs, next owner, and follow-up time.", { clarity: 3, empathy: 1, execution: 2, ethics: 2 }, -6, 1, "The day closes with shared understanding."),
        choice("Send a short status line", "Tell people the work moved forward without explaining details.", { clarity: -1, empathy: 0, execution: 1, ethics: -1 }, -2, 3, "The update is quick, but the next day may start with confusion."),
        choice("Reflect honestly on what is still unknown", "Be transparent about the remaining risk and the first move tomorrow.", { clarity: 2, empathy: 2, execution: 1, ethics: 3 }, -5, 1, "The update builds trust because it is clear about uncertainty.")
      ]
    }
  ].map((event, index, events) => enrichScenarioEvent({ ...event, ...shared }, career, index, events.length));
}

function enrichScenarioEvent(event, career, index, total) {
  const urgencyByDifficulty = { Low: 62, Medium: 52, High: 42 };
  const baseSeconds = urgencyByDifficulty[career.difficulty] || 52;
  const objectiveTemplates = [
    `Stabilize the morning signal and define the ${career.focus} decision.`,
    `Handle the stakeholder pushback without losing trust or clarity.`,
    `Turn disagreement into one defendable next move.`,
    `Prioritize the work that protects the mission before time runs out.`,
    `Absorb the surprise and prevent the wrong tradeoff.`,
    `Close the day with a clear decision, owner, and remaining risk.`
  ];
  return {
    ...event,
    objective: objectiveTemplates[index] || `Move the ${career.focus} mission forward.`,
    urgency: Math.max(24, baseSeconds - index * 3),
    alerts: getLiveAlerts(event, career, index, total)
  };
}

function getLiveAlerts(event, career, index, total) {
  const blueprint = getCareerBlueprint(career);
  const alertPool = [
    [`${sentenceCase(career.stakeholder)} is waiting for a clear decision.`, "stakeholder"],
    [`${blueprint.signal} is noisy. Check before committing.`, "signal"],
    [`${sentenceCase(career.pressure)} is increasing pressure on the room.`, "pressure"],
    [`${career.tools[index % career.tools.length]} has new context.`, "tool"],
    [`Only ${total - index} work blocks remain in the day.`, "time"]
  ];
  return alertPool.slice(0, index >= 3 ? 4 : 3);
}

function getChoiceSet(type, career, variant = 0) {
  const sets = {
    scope: [
      choice("Protect the core outcome", `Cut lower-value work and focus on the ${career.focus} decision that matters most.`, { clarity: 3, empathy: 0, execution: 3, ethics: 1 }, -9, 3, "The plan gets smaller, sharper, and easier to defend."),
      choice("Promise the full plan", "Try to satisfy every request even though the day is overloaded.", { clarity: -1, empathy: 1, execution: -1, ethics: -1 }, -17, 11, "People like the ambition, but the plan becomes fragile."),
      choice("Negotiate a phased plan", "Show what can happen now, what waits, and what risk each path carries.", { clarity: 3, empathy: 2, execution: 2, ethics: 1 }, -11, 3, "The team sees a practical path instead of a yes-or-no fight.")
    ],
    alignment: [
      choice("Write the decision logic", "Explain the decision rule, evidence, and next checkpoint.", { clarity: 3, empathy: 1, execution: 2, ethics: 1 }, -8, 3, "The message reduces confusion and gives people a clear place to respond."),
      choice("Keep the tone positive", "Reassure everyone without naming the real concern.", { clarity: -1, empathy: 1, execution: 1, ethics: -1 }, -3, 5, "The reply sounds calm, but the concern stays alive."),
      choice("Bring people into a short call", "Use a brief conversation to align on risk and ownership.", { clarity: 1, empathy: 3, execution: 1, ethics: 1 }, -10, 2, "The call costs energy, but trust improves.")
    ],
    tradeoff: [
      choice("Name the tradeoff out loud", "Say what each side is protecting before recommending a path.", { clarity: 2, empathy: 3, execution: 1, ethics: 2 }, -9, 3, "The disagreement becomes less personal and more solvable."),
      choice("Choose the loudest side", "Back the strongest voice so the meeting ends quickly.", { clarity: -1, empathy: -1, execution: 2, ethics: -2 }, -4, 8, "The meeting moves, but quieter risks are ignored."),
      choice("Use a quick evidence check", "Run a small test or inspect the best available signal before deciding.", { clarity: 2, empathy: 1, execution: 2, ethics: 1 }, -10, 2, "You avoid pure opinion and make the next step more credible.")
    ],
    evidence: [
      choice("Check the source of truth", `Inspect ${career.tools[0]} and ${career.tools[1]} before making a claim.`, { clarity: 3, empathy: 0, execution: 2, ethics: 3 }, -9, 2, "You catch the signal that matters and avoid overreacting."),
      choice("Use the first obvious explanation", "Move fast with the most visible theory.", { clarity: 0, empathy: 0, execution: 2, ethics: -2 }, -4, 7, "The answer is fast, but confidence is weaker than it sounds."),
      choice("Share confidence level clearly", "Give the best answer now, including what could change it.", { clarity: 2, empathy: 1, execution: 1, ethics: 3 }, -7, 2, "People can act without mistaking uncertainty for ignorance.")
    ],
    empathy: [
      choice("Ask what the person needs first", "Listen for the real concern before solving.", { clarity: 1, empathy: 3, execution: 1, ethics: 2 }, -8, 2, "The response feels human and reveals the real obstacle."),
      choice("Defend the original plan", "Explain why the plan was reasonable and ask them to keep going.", { clarity: 1, empathy: -2, execution: 1, ethics: -1 }, -4, 6, "The plan survives, but the person feels unheard."),
      choice("Offer two supportive options", "Give choice while keeping boundaries and progress.", { clarity: 2, empathy: 2, execution: 2, ethics: 1 }, -9, 3, "The person gets agency without the day losing structure.")
    ],
    ethics: [
      choice("Pause for the safety or fairness risk", "Slow down enough to check what could harm someone.", { clarity: 2, empathy: 1, execution: 0, ethics: 4 }, -9, 1, "You protect trust by treating the risk as real."),
      choice("Keep moving to protect the deadline", "Avoid slowing the work, even though the risk is unresolved.", { clarity: 0, empathy: -1, execution: 2, ethics: -3 }, -5, 9, "The deadline looks safer, but the decision is harder to defend."),
      choice("Escalate with options", "Bring the risk to the right person with two practical paths.", { clarity: 2, empathy: 1, execution: 2, ethics: 3 }, -8, 2, "You use judgment without pretending the answer is simple.")
    ],
    recap: [
      choice("Send a clear recap with owners", "Explain the decision, reason, tradeoffs, owner, and follow-up time.", { clarity: 3, empathy: 1, execution: 2, ethics: 2 }, -6, 1, "The day closes with shared understanding."),
      choice("Send a short status line", "Tell people the work moved forward without explaining details.", { clarity: -1, empathy: 0, execution: 1, ethics: -1 }, -2, 3, "The update is quick, but tomorrow may start with confusion."),
      choice("Be honest about uncertainty", "Name what is known, what is unknown, and what you will check next.", { clarity: 2, empathy: 2, execution: 1, ethics: 3 }, -5, 1, "The update builds trust because it is clear about uncertainty.")
    ]
  };

  const choices = sets[type] || sets.tradeoff;
  if (variant % 2 === 1) return [choices[2], choices[0], choices[1]];
  return choices;
}

function choice(label, detail, scores, energyDelta, stressDelta, consequence) {
  const strongest = [...skillNames].sort((a, b) => (scores[b] || 0) - (scores[a] || 0))[0];
  const riskLevel = stressDelta >= 8 || energyDelta <= -14 ? "High pressure" : stressDelta <= 2 ? "Controlled" : "Tradeoff";
  return { label, detail, scores, energyDelta, stressDelta, consequence, strongest, riskLevel };
}

function startSimulation(careerId) {
  const career = careers.find((item) => item.id === careerId);
  if (!career) {
    app.selectedCareerId = null;
    switchView("library");
    return;
  }
  const profile = getProfile();
  const mode = playModes[profile.playMode];
  const variant = getCareerRuns(career.id).length % 3;
  app.selectedCareerId = career.id;
  app.activeTab = "inbox";
  app.sim = {
    id: `sim-${Date.now()}`,
    career,
    scenario: buildScenario(career, variant),
    variant,
    playMode: profile.playMode,
    step: 0,
    energy: mode.energyStart,
    stress: mode.stressStart,
    scores: { clarity: 0, empathy: 0, execution: 0, ethics: 0 },
    choices: [],
    remaining: 0,
    lastStep: -1,
    pressureHits: 0,
    arena: {
      evidence: 35,
      trust: 42,
      momentum: 28,
      focus: 58,
      actionsUsed: [],
      combo: 0
    },
    scene: {
      step: -1,
      required: 2,
      hotspots: []
    },
    completed: false
  };
  closeReport();
  switchView("simulation");
  renderSimulation();
}

function renderSimulation() {
  if (!app.sim) return;
  const { career, scenario, step } = app.sim;
  const event = scenario[step] || scenario[scenario.length - 1];
  const progress = Math.round((step / scenario.length) * 100);
  if (app.sim.lastStep !== step) {
    app.sim.remaining = event.urgency;
    app.sim.lastStep = step;
    initSceneHotspots(event);
  }

  dom.simField.textContent = career.field;
  dom.simTitle.textContent = `One day as a ${career.title}`;
  dom.simMission.textContent = `Mission: ${career.mission}. Mode: ${playModes[app.sim.playMode].label}.`;
  dom.timeLabel.textContent = event.time;
  dom.energyLabel.textContent = `${Math.max(0, app.sim.energy)}%`;
  dom.stressLabel.textContent = `${Math.min(100, app.sim.stress)}%`;
  dom.progressLabel.textContent = `${progress}%`;
  renderStatusGauges(progress);
  dom.eventChannel.textContent = event.channel;
  dom.eventStep.textContent = `${Math.min(step + 1, scenario.length)} of ${scenario.length}`;
  dom.eventTitle.textContent = event.title;
  dom.eventBody.textContent = event.body;
  dom.consequenceBox.classList.add("hidden");
  dom.consequenceBox.textContent = "";

  renderGameHud(event);
  renderCommandCenter(event, progress);
  renderArenaControls();
  renderSceneTask(event);
  renderTimeline();
  renderEventArtifacts(event);
  renderChoices(event);
  renderWorkspace();
  renderSkillMeters();
  renderDecisionLog();
  startEventClock();
}

function renderArenaControls() {
  if (!dom.arenaStats || !dom.arenaActions || !app.sim?.arena) return;
  const arena = app.sim.arena;
  const actionsThisStep = arena.actionSteps?.filter((step) => step === app.sim.step).length || 0;
  const stats = [
    ["Facts", arena.evidence],
    ["Trust", arena.trust],
    ["Progress", arena.momentum],
    ["Calm", arena.focus]
  ];
  dom.arenaStats.innerHTML = stats.map(([label, value]) => `
    <div>
      <span>${escapeHtml(label)}</span>
      <strong>${Math.round(value)}</strong>
      <i style="width: ${Math.max(0, Math.min(100, value))}%"></i>
    </div>
  `).join("");

  dom.arenaActions.innerHTML = arenaActions.map((action) => `
    <button type="button" data-arena-action="${escapeHtml(action.id)}" ${actionsThisStep >= 2 ? "disabled" : ""}>
      <strong>${escapeHtml(action.label)}</strong>
      <span>${escapeHtml(action.detail)}</span>
    </button>
  `).join("");
  dom.arenaActions.classList.toggle("actions-limited", actionsThisStep >= 2);
}

function initSceneHotspots(event) {
  if (!app.sim?.scene) return;
  const career = app.sim.career;
  const blueprint = getCareerBlueprint(career);
  app.sim.scene = {
    step: app.sim.step,
    required: 2,
    hotspots: [
      {
        id: `evidence-${app.sim.step}`,
        type: "evidence",
        label: "Check clue",
        detail: blueprint.signal,
        x: 0.24,
        y: 0.28,
        effects: { evidence: 18, focus: 4, energy: -2, stress: -1, clarity: 1, ethics: 1 },
        resolved: false
      },
      {
        id: `stakeholder-${app.sim.step}`,
        type: "stakeholder",
        label: "Ask person",
        detail: sentenceCase(career.stakeholder),
        x: 0.56,
        y: 0.34,
        effects: { trust: 17, focus: 3, energy: -3, stress: -2, empathy: 1 },
        resolved: false
      },
      {
        id: `work-${app.sim.step}`,
        type: "work",
        label: "Do task",
        detail: career.tools[app.sim.step % career.tools.length],
        x: 0.42,
        y: 0.7,
        effects: { momentum: 20, energy: -5, stress: 2, execution: 1 },
        resolved: false
      },
      {
        id: `risk-${app.sim.step}`,
        type: "risk",
        label: "Reduce risk",
        detail: event.channel,
        x: 0.76,
        y: 0.62,
        effects: { focus: 16, stress: -5, energy: -2, ethics: 1 },
        resolved: false
      }
    ]
  };
}

function renderSceneTask(event) {
  if (!dom.sceneTaskTitle || !app.sim?.scene) return;
  const resolved = app.sim.scene.hotspots.filter((hotspot) => hotspot.resolved).length;
  const required = app.sim.scene.required;
  dom.sceneTaskTitle.textContent = event.objective;
  dom.sceneTaskProgress.textContent = resolved >= required
    ? "Good. Now make the decision."
    : `Click ${required - resolved} more glowing item${required - resolved === 1 ? "" : "s"} in the scene before deciding.`;
  dom.sceneTaskProgress.classList.toggle("ready", resolved >= required);
}

function resolveSceneHotspot(hotspot) {
  if (!app.sim || hotspot.resolved) return;
  hotspot.resolved = true;
  const arena = app.sim.arena;
  const effects = hotspot.effects;
  arena.evidence = clamp(arena.evidence + (effects.evidence || 0), 0, 100);
  arena.trust = clamp(arena.trust + (effects.trust || 0), 0, 100);
  arena.momentum = clamp(arena.momentum + (effects.momentum || 0), 0, 100);
  arena.focus = clamp(arena.focus + (effects.focus || 0), 0, 100);
  app.sim.energy = clamp(app.sim.energy + (effects.energy || 0), 0, 100);
  app.sim.stress = clamp(app.sim.stress + (effects.stress || 0), 0, 100);
  arena.actionsUsed.push(hotspot.type);
  arena.actionSteps = arena.actionSteps || [];
  arena.actionSteps.push(app.sim.step);
  skillNames.forEach((skill) => {
    app.sim.scores[skill] += effects[skill] || 0;
  });
  const currentEvent = app.sim.scenario[app.sim.step];
  currentEvent.alerts = [
    [`${hotspot.label}: ${hotspot.detail} helped your decision.`, hotspot.type],
    ...currentEvent.alerts
  ].slice(0, 4);
  renderSimulation();
}

function useArenaAction(actionId) {
  if (!app.sim || app.sim.completed) return;
  const action = arenaActions.find((item) => item.id === actionId);
  if (!action) return;
  const arena = app.sim.arena;
  arena.actionSteps = arena.actionSteps || [];
  const actionsThisStep = arena.actionSteps.filter((step) => step === app.sim.step).length;
  if (actionsThisStep >= 2) return;
  const repeatCount = arena.actionsUsed.filter((id) => id === actionId).length;
  const repeatPenalty = Math.min(8, repeatCount * 3);
  const effects = action.effects;

  arena.evidence = clamp(arena.evidence + (effects.evidence || 0) - repeatPenalty, 0, 100);
  arena.trust = clamp(arena.trust + (effects.trust || 0) - repeatPenalty, 0, 100);
  arena.momentum = clamp(arena.momentum + (effects.momentum || 0) - repeatPenalty, 0, 100);
  arena.focus = clamp(arena.focus + (effects.focus || 0), 0, 100);
  app.sim.energy = clamp(app.sim.energy + (effects.energy || 0), 0, 100);
  app.sim.stress = clamp(app.sim.stress + (effects.stress || 0), 0, 100);
  arena.actionsUsed.push(actionId);
  arena.actionSteps.push(app.sim.step);
  arena.combo = actionId === "scan" && arena.actionsUsed.at(-2) === "talk" ? arena.combo + 1 : arena.combo;

  skillNames.forEach((skill) => {
    app.sim.scores[skill] += effects[skill] || 0;
  });

  const currentEvent = app.sim.scenario[app.sim.step];
  currentEvent.alerts = [
    [`${action.label} changed the room: ${getArenaActionResult(actionId, repeatCount)}.`, "tool"],
    ...currentEvent.alerts
  ].slice(0, 5);

  renderSimulation();
}

function getArenaActionResult(actionId, repeatCount) {
  if (repeatCount > 1) return "the same move is starting to lose impact";
  const results = {
    scan: "evidence is clearer",
    talk: "stakeholder trust improved",
    build: "momentum increased",
    reset: "focus recovered"
  };
  return results[actionId] || "the situation shifted";
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function renderStatusGauges(progress) {
  const statusCards = document.querySelectorAll(".status-grid div");
  const values = [progress, app.sim.energy, app.sim.stress, progress];
  statusCards.forEach((card, index) => {
    const value = Math.max(0, Math.min(100, values[index] || 0));
    card.style.setProperty("--gauge", `${value}%`);
    card.classList.toggle("status-risk", index === 2 && value >= 55);
    card.classList.toggle("status-low", index === 1 && value <= 38);
  });
}

function renderGameHud(event) {
  if (!dom.gameObjective) return;
  const scenario = app.sim.scenario;
  dom.gameObjective.textContent = event.objective;
  dom.objectiveList.innerHTML = scenario.map((item, index) => {
    const state = index < app.sim.step ? "done" : index === app.sim.step ? "active" : "locked";
    return `
      <div class="objective-pill ${state}">
        <span>${index + 1}</span>
        <strong>${escapeHtml(item.channel)}</strong>
      </div>
    `;
  }).join("");
  renderClock();
  dom.liveAlerts.innerHTML = event.alerts.slice(0, 2).map(([text, type], index) => `
    <article class="alert-item ${escapeHtml(type)}" style="animation-delay: ${index * 80}ms">
      <span>${escapeHtml(type)}</span>
      <strong>${escapeHtml(text)}</strong>
    </article>
  `).join("");
}

function renderClock() {
  if (!dom.clockText || !app.sim) return;
  const current = app.sim.scenario[app.sim.step] || app.sim.scenario[app.sim.scenario.length - 1];
  const total = Math.max(1, current.urgency || 45);
  const remaining = Math.max(0, app.sim.remaining || 0);
  const percent = Math.round((remaining / total) * 100);
  const minutes = Math.floor(remaining / 60);
  const seconds = String(remaining % 60).padStart(2, "0");
  dom.clockText.textContent = `${minutes}:${seconds}`;
  dom.clockRing.style.setProperty("--clock", `${percent}%`);
  dom.clockRing.classList.toggle("urgent", percent <= 35);
  dom.clockRing.classList.toggle("expired", percent <= 0);
}

function startEventClock() {
  stopEventClock();
  if (!app.sim || app.sim.completed || typeof setInterval !== "function") return;
  app.eventTimer = setInterval(() => {
    if (!app.sim || app.sim.completed || app.view !== "simulation") {
      stopEventClock();
      return;
    }
    app.sim.remaining = Math.max(0, app.sim.remaining - 1);
    renderClock();
    if (app.sim.remaining === 0) {
      applyPressurePenalty();
    }
  }, 1000);
}

function stopEventClock() {
  if (app.eventTimer && typeof clearInterval === "function") clearInterval(app.eventTimer);
  app.eventTimer = null;
}

function applyPressurePenalty() {
  if (!app.sim || app.sim.timePenaltyStep === app.sim.step) return;
  app.sim.timePenaltyStep = app.sim.step;
  app.sim.pressureHits += 1;
  app.sim.stress = Math.min(100, app.sim.stress + 7);
  app.sim.energy = Math.max(0, app.sim.energy - 4);
  renderStatusGauges(Math.round((app.sim.step / app.sim.scenario.length) * 100));
  const warning = document.createElement("article");
  warning.className = "alert-item pressure";
  warning.innerHTML = `<span>deadline</span><strong>The room waited too long. Stress increased.</strong>`;
  dom.liveAlerts?.prepend(warning);
}

function getCareerBlueprint(career) {
  return fieldBlueprints[career.field] || {
    system: "Work system",
    signal: "Best evidence",
    stakes: "Quality and trust",
    environment: "Workday command room"
  };
}

function getPressureState() {
  if (!app.sim) return { label: "Stable", className: "stable" };
  if (app.sim.stress >= 72 || app.sim.energy <= 22) return { label: "Critical", className: "critical" };
  if (app.sim.stress >= 50 || app.sim.energy <= 42) return { label: "Tense", className: "tense" };
  return { label: "Stable", className: "stable" };
}

function renderCommandCenter(event, progress) {
  const career = app.sim.career;
  const blueprint = getCareerBlueprint(career);
  const pressure = getPressureState();
  const decisionQuality = getDecisionQuality();
  const energyWidth = Math.max(0, Math.min(100, app.sim.energy));
  const stressWidth = Math.max(0, Math.min(100, app.sim.stress));
  const progressWidth = Math.max(4, Math.min(100, progress));

  dom.simStageLabel.textContent = blueprint.environment;
  dom.simStageTitle.textContent = blueprint.system;
  dom.simStagePulse.textContent = pressure.label;
  dom.simStagePulse.className = pressure.className;
  dom.simWorldMap.style.setProperty("--field-accent", blueprint.accent || "#4f8cff");
  dom.simWorldMap.style.setProperty("--field-secondary", blueprint.secondary || "#20c997");
  dom.simWorldMap.innerHTML = `
    <div class="map-grid" aria-hidden="true">
      <span style="--x: 18%; --y: 34%; --size: 58px;"></span>
      <span style="--x: 47%; --y: 18%; --size: 74px;"></span>
      <span style="--x: 76%; --y: 52%; --size: 62px;"></span>
      <span style="--x: 34%; --y: 70%; --size: 48px;"></span>
    </div>
    <div class="map-node primary active-node" style="left: 14%; top: 26%;">
      <strong>${escapeHtml(career.title)}</strong>
      <span>${escapeHtml(career.focus)}</span>
    </div>
    <div class="map-node" style="left: 56%; top: 14%;">
      <strong>${escapeHtml(sentenceCase(career.stakeholder))}</strong>
      <span>Needs a defensible call</span>
    </div>
    <div class="map-node warning" style="left: 52%; top: 64%;">
      <strong>${escapeHtml(blueprint.stakes)}</strong>
      <span>${escapeHtml(career.pressure)}</span>
    </div>
    <div class="map-node evidence" style="left: 10%; top: 68%;">
      <strong>${escapeHtml(blueprint.signal)}</strong>
      <span>${escapeHtml(career.tools[0])}</span>
    </div>
    <div class="map-link one"></div>
    <div class="map-link two"></div>
  `;
  startSimulationAnimation();

  if (dom.decisionIntel) {
    dom.decisionIntel.innerHTML = `
      <div>
        <span>Decision quality</span>
        <strong>${decisionQuality.label}</strong>
        <div class="intel-bar"><i style="width: ${decisionQuality.percent}%"></i></div>
      </div>
      <div>
        <span>Energy reserve</span>
        <strong>${energyWidth}%</strong>
        <div class="intel-bar green"><i style="width: ${energyWidth}%"></i></div>
      </div>
      <div>
        <span>Pressure load</span>
        <strong>${stressWidth}%</strong>
        <div class="intel-bar red"><i style="width: ${stressWidth}%"></i></div>
      </div>
      <div>
        <span>Current signal</span>
        <strong>${escapeHtml(blueprint.signal)}</strong>
        <small>${escapeHtml(event.channel)}: ${escapeHtml(event.title)}</small>
      </div>
      <div>
        <span>Workday completion</span>
        <strong>${progressWidth}%</strong>
        <div class="intel-bar gold"><i style="width: ${progressWidth}%"></i></div>
      </div>
    `;
  }
}

function getDecisionQuality() {
  const total = skillNames.reduce((sum, skill) => sum + app.sim.scores[skill], 0);
  const arena = app.sim.arena || { evidence: 0, trust: 0, momentum: 0, focus: 0 };
  const arenaBonus = Math.round((arena.evidence + arena.trust + arena.momentum + arena.focus) / 18);
  const percent = Math.max(5, Math.min(100, 38 + total * 5 + arenaBonus - Math.round(app.sim.stress / 8)));
  if (percent >= 78) return { label: "High", percent };
  if (percent >= 58) return { label: "Solid", percent };
  if (percent >= 38) return { label: "Mixed", percent };
  return { label: "At risk", percent };
}

function startSimulationAnimation() {
  if (!dom.simCanvas || typeof dom.simCanvas.getContext !== "function" || typeof requestAnimationFrame !== "function") return;
  if (app.animationFrame) cancelAnimationFrame(app.animationFrame);
  const context = dom.simCanvas.getContext("2d");
  if (!context) return;

  const draw = (time = 0) => {
    if (!app.sim || app.view !== "simulation") {
      app.animationFrame = null;
      return;
    }

    const rect = dom.simCanvas.getBoundingClientRect ? dom.simCanvas.getBoundingClientRect() : { width: 900, height: 420 };
    const width = Math.max(1, Math.round(rect.width || dom.simCanvas.width));
    const height = Math.max(1, Math.round(rect.height || dom.simCanvas.height));
    if (dom.simCanvas.width !== width) dom.simCanvas.width = width;
    if (dom.simCanvas.height !== height) dom.simCanvas.height = height;

    const blueprint = getCareerBlueprint(app.sim.career);
    const stress = Math.max(0, Math.min(1, app.sim.stress / 100));
    const energy = Math.max(0.2, Math.min(1, app.sim.energy / 100));
    const speed = 0.00042 + stress * 0.0007;
    const pulse = (time * speed) % 1;

    context.clearRect(0, 0, width, height);
    drawCanvasGrid(context, width, height, blueprint, stress);
    drawCareerEnvironment(context, width, height, blueprint, stress, energy, time);
    drawSignalPath(context, width, height, blueprint, pulse, energy, stress);
    drawSignalPath(context, width, height, { accent: blueprint.secondary, secondary: blueprint.accent }, (pulse + 0.44) % 1, energy * 0.82, stress);
    drawSceneHotspots(context, width, height, pulse);
    app.animationFrame = requestAnimationFrame(draw);
  };

  app.animationFrame = requestAnimationFrame(draw);
}

function drawSceneHotspots(context, width, height, pulse) {
  if (!app.sim?.scene?.hotspots) return;
  context.save();
  app.sim.scene.hotspots.forEach((hotspot) => {
    const x = hotspot.x * width;
    const y = hotspot.y * height;
    const radius = hotspot.resolved ? 17 : 24 + Math.sin(pulse * Math.PI * 2) * 3;
    const color = getHotspotColor(hotspot.type);
    context.globalAlpha = hotspot.resolved ? 0.46 : 1;
    context.fillStyle = `${color}33`;
    context.beginPath();
    context.arc(x, y, radius + 12, 0, Math.PI * 2);
    context.fill();
    context.fillStyle = color;
    context.shadowColor = color;
    context.shadowBlur = hotspot.resolved ? 0 : 18;
    context.beginPath();
    context.arc(x, y, radius, 0, Math.PI * 2);
    context.fill();
    context.shadowBlur = 0;
    context.fillStyle = "#fff";
    context.font = "900 15px system-ui";
    context.textAlign = "center";
    context.textBaseline = "middle";
    context.fillText(getHotspotIcon(hotspot.type), x, y + 1);
    context.fillStyle = "rgba(255,255,255,0.94)";
    roundRect(context, x - 48, y + radius + 10, 96, 25, 7);
    context.fill();
    context.fillStyle = "#101318";
    context.font = "800 10px system-ui";
    context.fillText(hotspot.resolved ? "Done" : hotspot.label, x, y + radius + 23);
  });
  context.restore();
}

function getHotspotColor(type) {
  const colors = {
    evidence: "#4f8cff",
    stakeholder: "#20c997",
    work: "#f6bd4b",
    risk: "#ef6a4b"
  };
  return colors[type] || "#ffffff";
}

function getHotspotIcon(type) {
  const icons = {
    evidence: "?",
    stakeholder: "@",
    work: ">",
    risk: "!"
  };
  return icons[type] || "+";
}

function drawCareerEnvironment(context, width, height, blueprint, stress, energy, time) {
  const field = app.sim.career.field;
  const t = time * 0.001;
  context.save();
  context.globalAlpha = 0.92;

  if (field === "Healthcare") drawHealthcareScene(context, width, height, t, stress);
  else if (field === "Education") drawEducationScene(context, width, height, t, stress);
  else if (field === "Technology") drawTechnologyScene(context, width, height, t, stress);
  else if (field === "Engineering" || field === "Skilled Trades") drawEngineeringScene(context, width, height, t, stress);
  else if (field === "Transportation") drawTransportationScene(context, width, height, t, stress);
  else drawOperationsScene(context, width, height, blueprint, t, stress);

  drawActors(context, width, height, blueprint, t, stress, energy);
  drawFloatingWork(context, width, height, blueprint, t, stress);
  context.restore();
}

function drawTechnologyScene(context, width, height, t, stress) {
  drawDesk(context, width * 0.1, height * 0.62, width * 0.8, height * 0.18, "#1d2633");
  drawMonitor(context, width * 0.18, height * 0.25, width * 0.22, height * 0.26, "#4f8cff", t);
  drawMonitor(context, width * 0.56, height * 0.23, width * 0.24, height * 0.28, stress > 0.55 ? "#ef6a4b" : "#20c997", t + 1.4);
}

function drawHealthcareScene(context, width, height, t, stress) {
  drawDesk(context, width * 0.08, height * 0.66, width * 0.84, height * 0.14, "#1d3230");
  drawMonitor(context, width * 0.12, height * 0.24, width * 0.2, height * 0.22, stress > 0.55 ? "#ef6a4b" : "#20c997", t);
  drawBed(context, width * 0.5, height * 0.48, width * 0.28, height * 0.11);
}

function drawEducationScene(context, width, height, t, stress) {
  drawBoard(context, width * 0.1, height * 0.18, width * 0.42, height * 0.26, "#14785f");
  for (let i = 0; i < 5; i += 1) {
    drawDesk(context, width * (0.16 + i * 0.13), height * (0.62 + (i % 2) * 0.08), width * 0.08, height * 0.05, "#283747");
  }
  drawMonitor(context, width * 0.62, height * 0.22, width * 0.2, height * 0.22, stress > 0.55 ? "#f6bd4b" : "#4f8cff", t);
}

function drawEngineeringScene(context, width, height, t, stress) {
  drawDesk(context, width * 0.08, height * 0.66, width * 0.84, height * 0.13, "#2c3038");
  drawBlueprint(context, width * 0.12, height * 0.22, width * 0.28, height * 0.26, t);
  drawGear(context, width * 0.68, height * 0.36, 34 + stress * 10, t);
}

function drawTransportationScene(context, width, height, t, stress) {
  drawWindow(context, width * 0.12, height * 0.16, width * 0.76, height * 0.34, stress);
  drawDesk(context, width * 0.14, height * 0.68, width * 0.72, height * 0.1, "#202936");
  drawMonitor(context, width * 0.2, height * 0.52, width * 0.16, height * 0.13, "#4f8cff", t);
  drawMonitor(context, width * 0.62, height * 0.52, width * 0.16, height * 0.13, "#20c997", t + 0.9);
}

function drawOperationsScene(context, width, height, blueprint, t, stress) {
  drawDesk(context, width * 0.08, height * 0.64, width * 0.84, height * 0.15, "#202936");
  drawBoard(context, width * 0.12, height * 0.2, width * 0.26, height * 0.24, blueprint.accent || "#4f8cff");
  drawMonitor(context, width * 0.58, height * 0.24, width * 0.24, height * 0.24, stress > 0.55 ? "#ef6a4b" : blueprint.secondary || "#20c997", t);
}

function drawActors(context, width, height, blueprint, t, stress, energy) {
  const actors = [
    [width * 0.26, height * 0.58, "You", blueprint.accent || "#4f8cff"],
    [width * 0.5, height * 0.56 + Math.sin(t * 1.8) * 5, "Lead", blueprint.secondary || "#20c997"],
    [width * 0.74, height * 0.58, "Risk", stress > 0.55 ? "#ef6a4b" : "#f6bd4b"]
  ];
  actors.forEach(([x, y, label, color], index) => {
    const bob = Math.sin(t * 2 + index) * 3 * energy;
    context.fillStyle = color;
    context.beginPath();
    context.arc(x, y + bob, 15, 0, Math.PI * 2);
    context.fill();
    context.fillStyle = "rgba(255,255,255,0.92)";
    context.fillRect(x - 22, y + 18 + bob, 44, 30);
    context.fillStyle = "#101318";
    context.font = "700 10px system-ui";
    context.textAlign = "center";
    context.fillText(label, x, y + 38 + bob);
  });
}

function drawFloatingWork(context, width, height, blueprint, t, stress) {
  const count = 5 + Math.round(stress * 4);
  for (let i = 0; i < count; i += 1) {
    const x = ((t * (18 + i * 3) + i * 130) % (width + 120)) - 60;
    const y = height * (0.13 + (i % 4) * 0.12) + Math.sin(t + i) * 8;
    context.fillStyle = i % 3 === 0 && stress > 0.55 ? "rgba(239,106,75,0.9)" : "rgba(255,255,255,0.86)";
    roundRect(context, x, y, 78, 28, 7);
    context.fill();
    context.fillStyle = i % 3 === 0 && stress > 0.55 ? "#fff" : blueprint.accent || "#4f8cff";
    context.fillRect(x + 9, y + 9, 34 + (i % 3) * 8, 4);
    context.fillRect(x + 9, y + 17, 50, 3);
  }
}

function drawDesk(context, x, y, width, height, color) {
  context.fillStyle = color;
  roundRect(context, x, y, width, height, 12);
  context.fill();
  context.fillStyle = "rgba(255,255,255,0.08)";
  context.fillRect(x + 18, y + 12, width - 36, 4);
}

function drawMonitor(context, x, y, width, height, color, t) {
  context.fillStyle = "rgba(255,255,255,0.9)";
  roundRect(context, x, y, width, height, 10);
  context.fill();
  context.fillStyle = "#101318";
  roundRect(context, x + 8, y + 8, width - 16, height - 16, 7);
  context.fill();
  context.strokeStyle = color;
  context.lineWidth = 3;
  context.beginPath();
  const mid = y + height * 0.48;
  for (let i = 0; i < 6; i += 1) {
    const px = x + 20 + i * ((width - 40) / 5);
    const py = mid + Math.sin(t * 2 + i) * (height * 0.16);
    if (i === 0) context.moveTo(px, py);
    else context.lineTo(px, py);
  }
  context.stroke();
}

function drawBoard(context, x, y, width, height, color) {
  context.fillStyle = color;
  roundRect(context, x, y, width, height, 10);
  context.fill();
  context.fillStyle = "rgba(255,255,255,0.85)";
  for (let i = 0; i < 4; i += 1) {
    context.fillRect(x + 18, y + 22 + i * 24, width - 36 - i * 22, 5);
  }
}

function drawBlueprint(context, x, y, width, height, t) {
  context.fillStyle = "rgba(40,95,189,0.9)";
  roundRect(context, x, y, width, height, 10);
  context.fill();
  context.strokeStyle = "rgba(255,255,255,0.72)";
  context.lineWidth = 2;
  for (let i = 0; i < 5; i += 1) {
    context.strokeRect(x + 18 + i * 14, y + 18 + i * 9, width * 0.54, height * 0.44);
  }
  context.beginPath();
  context.arc(x + width * 0.72, y + height * 0.48, 24 + Math.sin(t) * 4, 0, Math.PI * 2);
  context.stroke();
}

function drawGear(context, x, y, radius, t) {
  context.save();
  context.translate(x, y);
  context.rotate(t);
  context.fillStyle = "rgba(246,189,75,0.9)";
  for (let i = 0; i < 10; i += 1) {
    context.rotate(Math.PI / 5);
    context.fillRect(radius - 6, -5, 18, 10);
  }
  context.beginPath();
  context.arc(0, 0, radius, 0, Math.PI * 2);
  context.fill();
  context.fillStyle = "#101318";
  context.beginPath();
  context.arc(0, 0, radius * 0.42, 0, Math.PI * 2);
  context.fill();
  context.restore();
}

function drawBed(context, x, y, width, height) {
  context.fillStyle = "rgba(255,255,255,0.92)";
  roundRect(context, x, y, width, height, 10);
  context.fill();
  context.fillStyle = "rgba(32,201,151,0.9)";
  roundRect(context, x + width * 0.08, y - height * 0.35, width * 0.2, height * 0.55, 8);
  context.fill();
}

function drawWindow(context, x, y, width, height, stress) {
  const gradient = context.createLinearGradient(x, y, x, y + height);
  gradient.addColorStop(0, stress > 0.55 ? "rgba(239,106,75,0.34)" : "rgba(79,140,255,0.36)");
  gradient.addColorStop(1, "rgba(255,255,255,0.08)");
  context.fillStyle = gradient;
  roundRect(context, x, y, width, height, 18);
  context.fill();
  context.strokeStyle = "rgba(255,255,255,0.24)";
  context.lineWidth = 3;
  context.beginPath();
  context.moveTo(x + width * 0.5, y);
  context.lineTo(x + width * 0.5, y + height);
  context.moveTo(x, y + height * 0.52);
  context.lineTo(x + width, y + height * 0.52);
  context.stroke();
}

function roundRect(context, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  context.beginPath();
  context.moveTo(x + r, y);
  context.arcTo(x + width, y, x + width, y + height, r);
  context.arcTo(x + width, y + height, x, y + height, r);
  context.arcTo(x, y + height, x, y, r);
  context.arcTo(x, y, x + width, y, r);
  context.closePath();
}

function drawCanvasGrid(context, width, height, blueprint, stress) {
  const lineAlpha = 0.07 + stress * 0.06;
  context.save();
  context.strokeStyle = `rgba(255,255,255,${lineAlpha})`;
  context.lineWidth = 1;
  for (let x = 0; x < width; x += 36) {
    context.beginPath();
    context.moveTo(x, 0);
    context.lineTo(x, height);
    context.stroke();
  }
  for (let y = 0; y < height; y += 36) {
    context.beginPath();
    context.moveTo(0, y);
    context.lineTo(width, y);
    context.stroke();
  }

  const gradient = context.createRadialGradient(width * 0.52, height * 0.42, 20, width * 0.52, height * 0.42, width * 0.78);
  gradient.addColorStop(0, `${blueprint.accent || "#4f8cff"}33`);
  gradient.addColorStop(0.48, `${blueprint.secondary || "#20c997"}18`);
  gradient.addColorStop(1, "rgba(5, 9, 18, 0)");
  context.fillStyle = gradient;
  context.fillRect(0, 0, width, height);
  context.restore();
}

function drawSignalPath(context, width, height, blueprint, pulse, energy, stress) {
  const points = [
    [width * 0.2, height * 0.34],
    [width * 0.42, height * 0.22],
    [width * 0.68, height * 0.28],
    [width * 0.64, height * 0.68],
    [width * 0.22, height * 0.74]
  ];
  const color = blueprint.accent || "#4f8cff";
  context.save();
  context.lineWidth = 2 + stress * 2;
  context.strokeStyle = `${color}55`;
  context.beginPath();
  points.forEach(([x, y], index) => {
    if (index === 0) context.moveTo(x, y);
    else context.lineTo(x, y);
  });
  context.stroke();

  const segmentCount = points.length - 1;
  const scaled = pulse * segmentCount;
  const index = Math.min(segmentCount - 1, Math.floor(scaled));
  const segmentPulse = scaled - index;
  const from = points[index];
  const to = points[index + 1];
  const x = from[0] + (to[0] - from[0]) * segmentPulse;
  const y = from[1] + (to[1] - from[1]) * segmentPulse;
  const radius = 7 + energy * 8 + Math.sin(pulse * Math.PI * 2) * 2;

  context.fillStyle = color;
  context.shadowColor = color;
  context.shadowBlur = 22;
  context.beginPath();
  context.arc(x, y, radius, 0, Math.PI * 2);
  context.fill();
  context.restore();
}

function renderEventArtifacts(event) {
  if (!dom.eventArtifacts || !app.sim) return;
  const career = app.sim.career;
  const labels = eventArtifactLabels[event.channel] || eventArtifactLabels[event.title] || ["Work artifact", "Signal", "Constraint"];
  const artifacts = labels.map((label, index) => {
    const values = [
      event.body,
      `${sentenceCase(career.stakeholder)} is watching ${career.focus}.`,
      `${career.tools[index % career.tools.length]} may change the answer.`
    ];
    return { label, text: values[index] || values[0] };
  });

  dom.eventArtifacts.innerHTML = artifacts.map((artifact) => `
    <div class="artifact-card">
      <span>${escapeHtml(artifact.label)}</span>
      <strong>${escapeHtml(artifact.text)}</strong>
    </div>
  `).join("");
}

function renderTimeline() {
  dom.timeline.innerHTML = "";
  app.sim.scenario.forEach((_, index) => {
    const item = document.createElement("div");
    item.className = "time-step";
    if (index < app.sim.step) item.classList.add("done");
    if (index === app.sim.step) item.classList.add("current");
    dom.timeline.appendChild(item);
  });
}

function renderChoices(event) {
  dom.choiceList.innerHTML = "";
  const resolved = app.sim.scene?.hotspots.filter((hotspot) => hotspot.resolved).length || 0;
  const ready = resolved >= (app.sim.scene?.required || 0);
  const selectedIndex = app.sim.pendingChoiceIndex ?? 0;
  const helper = document.createElement("div");
  helper.className = `command-header ${ready ? "ready" : ""}`;
  helper.innerHTML = `
    <span>${ready ? "Choose your move" : "Scene locked"}</span>
    <strong>${ready ? "Pick the final action for this moment." : "Click glowing items in the scene first."}</strong>
  `;
  dom.choiceList.appendChild(helper);

  event.choices.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = `choice-btn command-card ${index === selectedIndex ? "armed" : ""}`;
    button.type = "button";
    button.disabled = !ready;
    button.innerHTML = `
      <span class="choice-key">${getCommandIcon(option.strongest)}</span>
      <span class="choice-copy">
        <small>Move ${index + 1}</small>
        <strong>${escapeHtml(option.label)}</strong>
        <span>${escapeHtml(option.detail)}</span>
        <span class="choice-impact">
          <i>${escapeHtml(skillLabels[option.strongest])}</i>
          <i>${escapeHtml(option.riskLevel)}</i>
          <i>${option.energyDelta} energy</i>
          <i>+${option.stressDelta} stress</i>
        </span>
      </span>
    `;
    button.addEventListener("click", () => {
      app.sim.pendingChoiceIndex = index;
      renderChoices(event);
    });
    button.addEventListener("dblclick", () => chooseOption(option));
    dom.choiceList.appendChild(button);
  });

  const confirm = document.createElement("button");
  confirm.className = "commit-btn";
  confirm.type = "button";
  confirm.disabled = !ready;
  confirm.textContent = ready ? "Commit move" : "Play scene first";
  confirm.addEventListener("click", () => {
    if (!ready) return;
    chooseOption(event.choices[app.sim.pendingChoiceIndex ?? 0]);
  });
  dom.choiceList.appendChild(confirm);
}

function getCommandIcon(skill) {
  const icons = {
    clarity: "?",
    empathy: "@",
    execution: ">",
    ethics: "!"
  };
  return icons[skill] || "+";
}

function getWorkspaceEffect(tab, index) {
  const effects = {
    inbox: [
      { hotspot: "stakeholder", alert: "Inbox read: stakeholder concern is clearer." },
      { hotspot: "risk", alert: "Pressure note read: risk is easier to spot." },
      { hotspot: "evidence", alert: "Signal opened: facts improved." }
    ],
    chat: [
      { hotspot: "stakeholder", alert: "Chat reply: trust improved." },
      { hotspot: "risk", alert: "Team concern heard: calm improved." },
      { hotspot: "work", alert: "Team aligned: progress improved." }
    ],
    tasks: [
      { hotspot: "work", alert: "Task checked: progress improved." },
      { hotspot: "evidence", alert: "Tool opened: facts improved." },
      { hotspot: "risk", alert: "Owner clarified: calm improved." }
    ]
  };
  return effects[tab]?.[index % effects[tab].length] || effects.inbox[0];
}

function useWorkspaceUpdate(tab, index) {
  if (!app.sim?.scene?.hotspots) return;
  const effect = getWorkspaceEffect(tab, index);
  const hotspot = app.sim.scene.hotspots.find((item) => item.type === effect.hotspot && !item.resolved)
    || app.sim.scene.hotspots.find((item) => !item.resolved);
  if (hotspot) {
    resolveSceneHotspot(hotspot);
  } else {
    app.sim.stress = clamp(app.sim.stress - 2, 0, 100);
    app.sim.arena.focus = clamp(app.sim.arena.focus + 4, 0, 100);
    const currentEvent = app.sim.scenario[app.sim.step];
    currentEvent.alerts = [[effect.alert, tab], ...currentEvent.alerts].slice(0, 4);
    renderSimulation();
  }
}

function chooseOption(option) {
  if (!app.sim || app.sim.completed) return;
  const simId = app.sim.id;
  const mode = playModes[app.sim.playMode];
  stopEventClock();
  dom.choiceList.querySelectorAll("button").forEach((button) => {
    button.disabled = true;
    if (button.textContent.includes(option.label)) button.classList.add("selected");
  });
  document.querySelector(".event-card")?.classList.add("decision-locked");

  skillNames.forEach((skill) => {
    app.sim.scores[skill] += (option.scores[skill] || 0) + mode.scoreBonus + getArenaSkillBonus(skill);
  });
  app.sim.energy = Math.max(0, app.sim.energy + Math.round(option.energyDelta * mode.energyMultiplier));
  app.sim.stress = Math.min(100, Math.max(0, app.sim.stress + Math.round((option.stressDelta - getArenaStressBuffer()) * mode.stressMultiplier)));
  app.sim.choices.push({
    step: app.sim.step,
    label: option.label,
    consequence: option.consequence,
    scores: option.scores,
    strongest: option.strongest,
    riskLevel: option.riskLevel,
    energyDelta: option.energyDelta,
    stressDelta: option.stressDelta
  });

  dom.consequenceBox.textContent = option.consequence;
  dom.consequenceBox.classList.remove("hidden");

  setTimeout(() => {
    if (!app.sim || app.sim.id !== simId) return;
    document.querySelector(".event-card")?.classList.remove("decision-locked");
    app.sim.step += 1;
    if (app.sim.step >= app.sim.scenario.length) {
      finishSimulation();
    } else {
      renderSimulation();
    }
  }, 920);
}

function getArenaSkillBonus(skill) {
  const arena = app.sim?.arena;
  if (!arena) return 0;
  const map = {
    clarity: arena.evidence,
    empathy: arena.trust,
    execution: arena.momentum,
    ethics: Math.min(arena.evidence, arena.focus)
  };
  return map[skill] >= 72 ? 1 : 0;
}

function getArenaStressBuffer() {
  const arena = app.sim?.arena;
  if (!arena) return 0;
  return arena.focus >= 74 ? 2 : arena.focus >= 58 ? 1 : 0;
}

function renderWorkspace() {
  dom.tabButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === app.activeTab);
  });

  const career = app.sim.career;
  const blueprint = getCareerBlueprint(career);
  const step = app.sim.step;
  const currentEvent = app.sim.scenario[step] || app.sim.scenario[app.sim.scenario.length - 1];
  const lastChoice = app.sim.choices[app.sim.choices.length - 1];
  const feeds = {
    inbox: [
      ["Priority", `${sentenceCase(career.stakeholder)} asks for a decision on ${career.focus}.`],
      ["Pressure", `${sentenceCase(career.pressure)}. Reply before the next checkpoint.`],
      ["Signal", `${blueprint.signal} should be checked before the final call.`],
      ["Reminder", `End the day with a clear update and next owner.`]
    ],
    chat: [
      ["Team", `Can we make this simpler without missing the goal?`],
      ["Stakeholder", `I need to understand the risk before I support this.`],
      ["You", lastChoice ? lastChoice.label : "Reviewing the situation."],
      ["System", `${getDecisionQuality().label} decision quality with ${getPressureState().label.toLowerCase()} pressure.`]
    ],
    tasks: [
      [step > 0 ? "Done" : "Today", `Define the core ${career.focus} decision.`],
      [step > 2 ? "Done" : "Today", `Use ${career.tools[0]} and ${career.tools[1]} to check the facts.`],
      [step > 4 ? "Ready" : "Today", `Send a final update to the ${career.stakeholder}.`],
      ["Stretch", `Compare this role with another ${career.field} workday after the report.`]
    ],
    calendar: [
      [currentEvent.time, currentEvent.title],
      ["12:15 PM", `${sentenceCase(career.focus)} checkpoint`],
      ["2:30 PM", `${blueprint.stakes} review`],
      ["4:40 PM", `Decision recap with ${career.stakeholder}`]
    ],
    docs: [
      [career.tools[0], `Primary source for today's decision.`],
      [career.tools[1], `Supporting context that may change the answer.`],
      [career.tools[2], `Use this before the final update.`],
      [blueprint.system, `Map the goal, signal, risk, and owner before deciding.`]
    ]
  };

  dom.workspaceFeed.innerHTML = feeds[app.activeTab].map(([title, text], index) => `
    <button class="feed-item" type="button" data-work-update="${index}">
      <strong>${escapeHtml(title)}</strong>
      <span>${escapeHtml(text)}</span>
    </button>
  `).join("");
}

function renderDecisionLog() {
  if (!dom.decisionLog || !app.sim) return;
  if (!app.sim.choices.length) {
    dom.decisionLog.innerHTML = `<p class="empty-copy">No decisions yet. Your choices will build a replayable career pattern here.</p>`;
    return;
  }

  dom.decisionLog.innerHTML = app.sim.choices.map((decision) => {
    const event = app.sim.scenario[decision.step];
    return `
      <article class="decision-log-item">
        <header>
          <span>${escapeHtml(event.time)}</span>
          <strong>${escapeHtml(skillLabels[decision.strongest] || "Judgment")}</strong>
        </header>
        <p>${escapeHtml(decision.label)}</p>
        <small>${escapeHtml(decision.riskLevel)} - ${decision.energyDelta} energy, +${decision.stressDelta} stress</small>
      </article>
    `;
  }).join("");
}

function renderSkillMeters() {
  dom.skillMeters.innerHTML = skillNames.map((skill) => {
    const raw = app.sim.scores[skill];
    const percent = Math.max(0, Math.min(100, 50 + raw * 8));
    const level = percent >= 76 ? "Strong" : percent >= 56 ? "Good" : percent >= 38 ? "Building" : "Needs care";
    return `
      <div class="meter-row">
        <header><span>${skillLabels[skill]}</span><span>${level}</span></header>
        <div class="meter-track"><div class="meter-fill" style="width: ${percent}%"></div></div>
      </div>
    `;
  }).join("");
}

function finishSimulation() {
  app.sim.completed = true;
  stopEventClock();
  const beforeAchievements = getUnlockedAchievements(app.progress.runs).map((item) => item.id);
  const report = buildReport(app.sim);
  report.newAchievementIds = getUnlockedAchievements([report, ...app.progress.runs])
    .filter((item) => !beforeAchievements.includes(item.id))
    .map((item) => item.id);
  app.progress.runs.unshift(report);
  app.progress.runs = app.progress.runs.slice(0, 60);
  app.lastReport = report;
  saveProgress();
  renderReport(report);
  renderDashboard();
}

function getDecisionPattern(choices) {
  if (!choices.length) return "No decisions recorded";
  const counts = choices.reduce((map, decision) => {
    const key = decision.strongest || "clarity";
    map[key] = (map[key] || 0) + 1;
    return map;
  }, {});
  const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
  const pressureMoves = choices.filter((decision) => decision.riskLevel === "High pressure").length;
  const pressureText = pressureMoves >= 2 ? "often accepted heavy pressure" : pressureMoves === 1 ? "accepted pressure once" : "kept pressure controlled";
  return `${skillLabels[top]} led most choices and you ${pressureText}.`;
}

function getRiskProfile(choices) {
  const stressCost = choices.reduce((sum, decision) => sum + (decision.stressDelta || 0), 0);
  const energyCost = Math.abs(choices.reduce((sum, decision) => sum + (decision.energyDelta || 0), 0));
  if (stressCost >= 34 || energyCost >= 62) return "High load";
  if (stressCost >= 20 || energyCost >= 42) return "Moderate load";
  return "Controlled load";
}

function buildReport(sim) {
  const scoreTotal = skillNames.reduce((sum, skill) => sum + sim.scores[skill], 0);
  const energyBonus = Math.round(sim.energy / 10);
  const stressPenalty = Math.round(sim.stress / 14);
  const fitScore = Math.max(0, Math.min(100, 52 + scoreTotal * 4 + energyBonus - stressPenalty));
  const strongestSkill = [...skillNames].sort((a, b) => sim.scores[b] - sim.scores[a])[0];
  const weakestSkill = [...skillNames].sort((a, b) => sim.scores[a] - sim.scores[b])[0];
  const recommended = getRecommendedCareer(sim.career, strongestSkill);

  return {
    id: `run-${Date.now()}`,
    careerId: sim.career.id,
    date: new Date().toISOString(),
    playMode: sim.playMode,
    scenarioType: getCareerScenarioPack(sim.career).authored ? "Authored" : "Adaptive",
    fitScore,
    energy: sim.energy,
    stress: sim.stress,
    scores: { ...sim.scores },
    strongestSkill,
    weakestSkill,
    choices: sim.choices,
    pressureHits: sim.pressureHits || 0,
    arena: { ...sim.arena },
    decisionPattern: getDecisionPattern(sim.choices),
    riskProfile: getRiskProfile(sim.choices),
    recommendedCareerId: recommended.id
  };
}

function getRecommendedCareer(currentCareer, strongestSkill) {
  const fieldMatches = careers.filter((career) => career.field === currentCareer.field && career.id !== currentCareer.id);
  if (fieldMatches.length) return fieldMatches[0];
  const skillMap = {
    clarity: ["Data Analyst", "Lawyer", "Project Manager"],
    empathy: ["Psychologist", "Teacher", "UX Designer"],
    execution: ["Software Engineer", "Firefighter", "Chef"],
    ethics: ["Doctor", "Journalist", "Social Worker"]
  };
  const found = careers.find((career) => skillMap[strongestSkill].includes(career.title));
  return found || careers.find((career) => career.id !== currentCareer.id) || careers[0];
}

function renderReport(report) {
  const career = getCareer(report.careerId);
  const recommended = getCareer(report.recommendedCareerId);
  dom.reportTitle.textContent = `${getFitLabel(report.fitScore)} fit for ${career.title}`;
  dom.reportSummary.textContent = getReportSummary(report, career);
  dom.reportStats.innerHTML = `
    <div><strong>${report.fitScore}</strong><span>Fit score</span></div>
    <div><strong>${report.energy}%</strong><span>Energy left</span></div>
    <div><strong>${report.stress}%</strong><span>Stress</span></div>
    <div><strong>${skillLabels[report.strongestSkill]}</strong><span>Strongest skill</span></div>
    <div><strong>${escapeHtml(report.riskProfile || "Recorded")}</strong><span>Decision load</span></div>
    <div><strong>${report.pressureHits || 0}</strong><span>Deadline hits</span></div>
  `;
  dom.achievementUnlocks.innerHTML = renderAchievementCards(
    achievementCatalog.filter((item) => report.newAchievementIds?.includes(item.id)),
    true
  );
  dom.reflectionList.innerHTML = `
    <div class="reflection-card"><strong>What this role rewards</strong><p>${escapeHtml(career.title)} work rewards ${escapeHtml(career.traits.join(", "))}.</p></div>
    <div class="reflection-card"><strong>You might enjoy this role if</strong><p>${escapeHtml(getEnjoymentSignal(career, report))}</p></div>
    <div class="reflection-card"><strong>This role may frustrate you if</strong><p>${escapeHtml(getFrustrationSignal(career, report))}</p></div>
    <div class="reflection-card"><strong>Skill to improve</strong><p>Practice ${escapeHtml(skillLabels[report.weakestSkill].toLowerCase())} before replaying this role.</p></div>
    <div class="reflection-card"><strong>Decision pattern</strong><p>${escapeHtml(report.decisionPattern || getDecisionPattern(report.choices || []))}</p></div>
    <div class="reflection-card"><strong>Pressure handling</strong><p>${escapeHtml(getPressureReflection(report))}</p></div>
    <div class="reflection-card"><strong>Simulation play</strong><p>${escapeHtml(getArenaReflection(report))}</p></div>
    <div class="reflection-card"><strong>Try next</strong><p>${escapeHtml(recommended.title)} may fit because it uses related strengths in a different setting.</p></div>
    <div class="reflection-card"><strong>Career comparison</strong><p>${escapeHtml(getComparisonText(report, career, recommended))}</p></div>
  `;
  dom.tryRecommendedBtn.dataset.start = recommended.id;
  dom.reportModal.classList.remove("hidden");
}

function getPressureReflection(report) {
  if (!report.pressureHits) return "You made decisions inside the time window, which kept the workday from spiraling.";
  if (report.pressureHits === 1) return "One deadline slipped, but you recovered enough to finish the day.";
  return "Multiple deadlines slipped. Replay this role and make earlier calls to feel how the career changes.";
}

function getArenaReflection(report) {
  const arena = report.arena || {};
  const actions = arena.actionsUsed || [];
  if (!actions.length) return "You made the big decisions without using many live simulation actions.";
  const favorite = actions.reduce((counts, action) => {
    counts[action] = (counts[action] || 0) + 1;
    return counts;
  }, {});
  const top = Object.entries(favorite).sort((a, b) => b[1] - a[1])[0][0];
  const label = arenaActions.find((action) => action.id === top)?.label || "Live actions";
  return `${label} was your most-used move. Final resources: evidence ${Math.round(arena.evidence || 0)}, trust ${Math.round(arena.trust || 0)}, momentum ${Math.round(arena.momentum || 0)}, focus ${Math.round(arena.focus || 0)}.`;
}

function getUnlockedAchievements(runs) {
  return achievementCatalog.filter((achievement) => achievement.check(runs));
}

function renderAchievementCards(items, unlockedOnly = false) {
  if (!items.length && unlockedOnly) return "";
  const source = unlockedOnly ? items : achievementCatalog;
  const unlockedIds = new Set(getUnlockedAchievements(app.progress.runs).map((item) => item.id));
  return source.map((achievement) => {
    const unlocked = unlockedOnly || unlockedIds.has(achievement.id);
    return `
      <article class="achievement-card ${unlocked ? "unlocked" : "locked"}">
        <strong>${escapeHtml(achievement.title)}</strong>
        <span>${escapeHtml(unlocked ? achievement.description : `Locked: ${achievement.description}`)}</span>
      </article>
    `;
  }).join("");
}

function getEnjoymentSignal(career, report) {
  const skill = skillLabels[report.strongestSkill].toLowerCase();
  return `you like ${career.focus}, can handle ${career.pressure}, and enjoy using ${skill} under real constraints.`;
}

function getFrustrationSignal(career, report) {
  const skill = skillLabels[report.weakestSkill].toLowerCase();
  return `you dislike ambiguous requests from a ${career.stakeholder}, or if ${skill} drains you quickly.`;
}

function getComparisonText(report, career, recommended) {
  const score = getCareerMatchScore(recommended);
  return `${career.title} tested ${career.focus}. ${recommended.title} is a useful comparison because it shares some strengths but sits in ${recommended.field}. Profile match: ${score}.`;
}

function getFitLabel(score) {
  if (score >= 86) return "Excellent";
  if (score >= 72) return "Strong";
  if (score >= 58) return "Promising";
  if (score >= 44) return "Mixed";
  return "Low";
}

function getReportSummary(report, career) {
  if (report.fitScore >= 86) {
    return `You handled the ${career.focus} pressure with mature judgment. This career may be worth deeper exploration.`;
  }
  if (report.fitScore >= 72) {
    return `You showed useful instincts for this role, especially when the work became ambiguous.`;
  }
  if (report.fitScore >= 58) {
    return `You found parts of the role that worked, but some decisions needed clearer communication or stronger follow-through.`;
  }
  if (report.fitScore >= 44) {
    return `This role had some friction. Replay it once before ruling it out, because different choices can change the feel of the day.`;
  }
  return `This workday was difficult for your current decision style. That is still useful career information.`;
}

function closeReport() {
  dom.reportModal.classList.add("hidden");
}

function renderProgress() {
  renderHistory();
  renderRecommendations();
  dom.achievementList.innerHTML = renderAchievementCards(achievementCatalog);
}

function getAccount() {
  app.progress.account = normalizeAccount(app.progress.account);
  return app.progress.account;
}

function renderClassroom() {
  if (!dom.classroomMetrics || !dom.classroomInsights) return;
  const runs = app.progress.runs;
  const uniqueCareers = new Set(runs.map((run) => run.careerId)).size;
  const avgFit = runs.length ? Math.round(runs.reduce((sum, run) => sum + run.fitScore, 0) / runs.length) : 0;
  const best = [...runs].sort((a, b) => b.fitScore - a.fitScore)[0];
  const unlocked = getUnlockedAchievements(runs).length;

  dom.classroomMetrics.innerHTML = `
    <article class="panel stat-panel"><span class="stat-value">${runs.length}</span><h2>Completed days</h2><p>Total simulations completed by this learner.</p></article>
    <article class="panel stat-panel"><span class="stat-value">${uniqueCareers}</span><h2>Careers tried</h2><p>Unique roles explored across the library.</p></article>
    <article class="panel stat-panel"><span class="stat-value">${avgFit}</span><h2>Average fit</h2><p>Useful for counseling trends, not as a final judgment.</p></article>
    <article class="panel stat-panel"><span class="stat-value">${unlocked}</span><h2>Badges</h2><p>Achievement signals earned through play.</p></article>
  `;

  const recommendations = getProfileRecommendations(4);
  const insights = [
    best ? `Strongest current signal: ${getCareer(best.careerId).title} with fit ${best.fitScore}.` : "No simulations completed yet.",
    runs.length >= 3 ? "Enough history exists for a first counseling conversation." : "Run at least three simulations before making guidance claims.",
    `Recommended next roles: ${recommendations.map((career) => career.title).join(", ")}.`
  ];

  dom.classroomInsights.innerHTML = insights.map((text) => `
    <article class="history-card">
      <header><strong>Guidance insight</strong></header>
      <p>${escapeHtml(text)}</p>
    </article>
  `).join("");
}

function renderPlans() {
  if (!dom.planGrid) return;
  const account = getAccount();
  dom.planGrid.innerHTML = planCatalog.map((plan) => `
    <article class="plan-card ${account.plan === plan.name ? "active" : ""}">
      <span class="tag ${plan.name === "School" ? "gold" : "green"}">${escapeHtml(plan.audience)}</span>
      <h2>${escapeHtml(plan.name)}</h2>
      <strong>${escapeHtml(plan.price)}</strong>
      <ul>
        ${plan.features.map((feature) => `<li>${escapeHtml(feature)}</li>`).join("")}
      </ul>
      <button class="${account.plan === plan.name ? "secondary-btn" : "primary-btn"}" type="button" data-plan="${escapeHtml(plan.name)}">
        ${account.plan === plan.name ? "Current plan" : "Choose plan"}
      </button>
    </article>
  `).join("");
}

function renderAccount() {
  if (!dom.accountName) return;
  const account = getAccount();
  dom.accountName.value = account.name;
  dom.accountEmail.value = account.email;
  dom.accountRoleInputs.forEach((input) => {
    input.checked = input.value === account.role;
  });
  dom.accountPlanInputs.forEach((input) => {
    input.checked = input.value === account.plan;
  });
  dom.accountStatusTitle.textContent = account.name ? account.name : "Local learner";
  dom.accountStatus.innerHTML = `
    <div><strong>Email</strong><span>${escapeHtml(account.email || "Not set")}</span></div>
    <div><strong>Role</strong><span>${escapeHtml(account.role)}</span></div>
    <div><strong>Plan</strong><span>${escapeHtml(account.plan)}</span></div>
    <div><strong>Storage</strong><span>Saved locally. Backend scaffold is included for production migration.</span></div>
  `;
}

function saveAccountFromForm() {
  const role = [...dom.accountRoleInputs].find((input) => input.checked)?.value || defaultAccount.role;
  const plan = [...dom.accountPlanInputs].find((input) => input.checked)?.value || defaultAccount.plan;
  app.progress.account = normalizeAccount({
    name: dom.accountName.value.trim(),
    email: dom.accountEmail.value.trim(),
    role,
    plan
  });
  saveProgress();
  renderAccount();
  renderPlans();
}

function renderHistory() {
  if (!app.progress.runs.length) {
    dom.historyList.innerHTML = `<p class="empty-copy">No completed simulations yet. Start a career day to build your history.</p>`;
    return;
  }

  dom.historyList.innerHTML = app.progress.runs.map((run) => {
    const career = getCareer(run.careerId);
    const date = new Date(run.date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
    return `
      <article class="history-card">
        <header>
          <div>
            <strong>${escapeHtml(career.title)}</strong>
            <span>${escapeHtml(career.field)} - ${escapeHtml(date)}</span>
          </div>
          <strong>${run.fitScore}</strong>
        </header>
        <p>${escapeHtml(getReportSummary(run, career))}</p>
      </article>
    `;
  }).join("");
}

function renderRecommendations() {
  const playedIds = new Set(app.progress.runs.map((run) => run.careerId));
  const recent = app.progress.runs[0];
  let recommended = [];

  if (recent) {
    recommended.push(getCareer(recent.recommendedCareerId));
    const recentCareer = getCareer(recent.careerId);
    recommended.push(...careers.filter((career) => career.field === recentCareer.field && !playedIds.has(career.id)).slice(0, 2));
  }

  recommended.push(...careers.filter((career) => !playedIds.has(career.id)).slice(0, 4));
  recommended = [...new Map(recommended.map((career) => [career.id, career])).values()].slice(0, 4);

  dom.recommendationList.innerHTML = recommended.map((career) => `
    <article class="recommendation-card">
      <strong>${escapeHtml(career.title)}</strong>
      <span>${escapeHtml(career.field)} - practice ${escapeHtml(career.focus)}</span>
      <button class="primary-btn" type="button" data-start="${career.id}">Start</button>
    </article>
  `).join("");
}

function buildCounselorSummary(report = null) {
  const runs = report ? [report] : app.progress.runs;
  const profile = getProfile();
  const lines = [
    "SkillRova Career Simulator Summary",
    `Generated: ${new Date().toLocaleString()}`,
    "",
    "Learner profile",
    `- Interests: ${profile.traits.join(", ")}`,
    `- Decision style: ${profile.decisionStyle}`,
    `- Default play mode: ${profile.playMode}`,
    "",
    "Completed simulations"
  ];

  if (!runs.length) {
    lines.push("- No simulations completed yet.");
  } else {
    runs.forEach((run) => {
      const career = getCareer(run.careerId);
      lines.push(`- ${career.title}: fit ${run.fitScore}, mode ${run.playMode || "Realistic"}, strongest ${skillLabels[run.strongestSkill]}, improve ${skillLabels[run.weakestSkill]}, load ${run.riskProfile || "not recorded"}, deadline hits ${run.pressureHits || 0}`);
      if (run.decisionPattern) lines.push(`  Pattern: ${run.decisionPattern}`);
      if (run.arena?.actionsUsed?.length) lines.push(`  Simulation actions used: ${run.arena.actionsUsed.length}`);
    });
  }

  const best = [...app.progress.runs].sort((a, b) => b.fitScore - a.fitScore)[0];
  if (best) {
    const career = getCareer(best.careerId);
    lines.push("", "Current strongest signal", `- ${career.title} with fit score ${best.fitScore}.`);
  }

  const unlocked = getUnlockedAchievements(app.progress.runs);
  lines.push("", "Achievements", unlocked.length ? unlocked.map((item) => `- ${item.title}`).join("\n") : "- None yet.");
  lines.push("", "Recommended next roles", ...getProfileRecommendations(4).map((career) => `- ${career.title} (${career.field})`));
  return lines.join("\n");
}

function downloadTextFile(filename, text) {
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function clearProgress() {
  if (!window.confirm("Clear all saved simulation history from this browser?")) return;
  app.progress = { runs: [], profile: getProfile(), account: getAccount() };
  saveProgress();
  renderDashboard();
  renderProgress();
  renderLibrary();
  renderClassroom();
}

function bindEvents() {
  dom.navButtons.forEach((button) => {
    button.addEventListener("click", () => switchView(button.dataset.view));
  });

  dom.viewJumps.forEach((button) => {
    button.addEventListener("click", () => switchView(button.dataset.viewJump));
  });

  dom.startFeaturedBtn.addEventListener("click", () => switchView("library"));
  dom.saveProfileBtn.addEventListener("click", saveProfileFromForm);
  dom.resetProfileBtn.addEventListener("click", () => {
    app.progress.profile = { ...defaultProfile };
    dom.playModeSelect.value = defaultProfile.playMode;
    saveProgress();
    renderProfile();
    renderDashboard();
    renderLibrary();
  });
  dom.careerSearch.addEventListener("input", renderLibrary);
  dom.fieldFilter.addEventListener("change", renderLibrary);
  dom.difficultyFilter.addEventListener("change", renderLibrary);
  dom.sortSelect.addEventListener("change", renderLibrary);
  dom.playModeSelect.addEventListener("change", () => {
    app.progress.profile = { ...getProfile(), playMode: dom.playModeSelect.value };
    saveProgress();
    renderLibrary();
    renderProfile();
  });
  dom.exitSimBtn.addEventListener("click", () => {
    app.sim = null;
    switchView("library");
  });
  dom.restartSimBtn.addEventListener("click", () => {
    if (app.sim) startSimulation(app.sim.career.id);
  });
  dom.clearProgressBtn.addEventListener("click", clearProgress);
  dom.exportProgressBtn.addEventListener("click", () => {
    downloadTextFile("skillrova-counselor-summary.txt", buildCounselorSummary());
  });
  dom.exportClassroomBtn?.addEventListener("click", () => {
    downloadTextFile("skillrova-classroom-report.txt", buildCounselorSummary());
  });
  dom.saveAccountBtn?.addEventListener("click", saveAccountFromForm);
  dom.closeReportBtn.addEventListener("click", closeReport);
  dom.downloadReportBtn.addEventListener("click", () => {
    if (app.lastReport) {
      downloadTextFile("skillrova-report.txt", buildCounselorSummary(app.lastReport));
    }
  });
  dom.backToLibraryBtn.addEventListener("click", () => {
    closeReport();
    switchView("library");
  });
  dom.tryRecommendedBtn.addEventListener("click", () => {
    const careerId = dom.tryRecommendedBtn.dataset.start;
    if (careerId) startSimulation(careerId);
  });

  dom.simCanvas?.addEventListener("click", handleSceneClick);

  dom.tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      app.activeTab = button.dataset.tab;
      renderWorkspace();
    });
  });

  document.body.addEventListener("click", (event) => {
    const previewButton = event.target.closest("[data-preview]");
    const startButton = event.target.closest("[data-start]");
    const arenaButton = event.target.closest("[data-arena-action]");
    const updateButton = event.target.closest("[data-work-update]");

    if (previewButton) {
      app.selectedCareerId = previewButton.dataset.preview;
      renderLibrary();
    }

    if (startButton) {
      startSimulation(startButton.dataset.start);
    }

    if (arenaButton) {
      useArenaAction(arenaButton.dataset.arenaAction);
    }

    if (updateButton) {
      useWorkspaceUpdate(app.activeTab, Number(updateButton.dataset.workUpdate));
    }

    const planButton = event.target.closest("[data-plan]");
    if (planButton) {
      app.progress.account = { ...getAccount(), plan: planButton.dataset.plan };
      saveProgress();
      renderPlans();
      renderAccount();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !dom.reportModal.classList.contains("hidden")) {
      closeReport();
    }
  });
}

function handleSceneClick(event) {
  if (!app.sim?.scene?.hotspots?.length) return;
  const rect = dom.simCanvas.getBoundingClientRect();
  const x = (event.clientX - rect.left) / Math.max(1, rect.width);
  const y = (event.clientY - rect.top) / Math.max(1, rect.height);
  const hit = app.sim.scene.hotspots.find((hotspot) => {
    if (hotspot.resolved) return false;
    const dx = hotspot.x - x;
    const dy = hotspot.y - y;
    return Math.sqrt(dx * dx + dy * dy) < 0.08;
  });
  if (hit) resolveSceneHotspot(hit);
}

function init() {
  renderFilters();
  bindEvents();
  dom.playModeSelect.value = getProfile().playMode;
  renderDashboard();
  renderProfile();
  renderLibrary();
  renderProgress();
  renderClassroom();
  renderPlans();
  renderAccount();
}

init();
