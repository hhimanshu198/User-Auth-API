# SkillRova

SkillRova is a career simulator for students aged 12-25 who want to understand what careers actually feel like.

Instead of reading generic descriptions, students live through realistic simulated workdays with emails, meetings, tasks, tradeoffs, pressure, and end-of-day reflection reports.

## Problem

Students often choose subjects, degrees, internships, or careers without knowing what the day-to-day work actually feels like.

Most career tools explain careers from the outside. This app should help students experience careers from the inside.

## How It Works

The app gives the player a realistic day in a career role.

For each career simulation, the player may deal with:

- Emails from teammates and stakeholders
- Calendar meetings
- Chat messages
- Role-specific decisions
- Prioritization tasks
- Deadlines
- Tradeoffs between users, business goals, engineering effort, and design quality
- Feedback based on their choices

The goal is not just to "win." The goal is to understand what the career feels like.

## Target Audience

- Middle school students exploring future interests
- High school students choosing subjects or activities
- College students choosing majors, internships, or first jobs
- Early career learners comparing different career paths

## Product Vision

SkillRova should feel modern, immersive, and useful.

It should be more than a quiz. It should feel like a short interactive workday where every choice teaches the player something about the role.

## Core Experience

1. Choose a career simulation.
2. Start the workday.
3. Receive emails, messages, meetings, and tasks.
4. Make decisions under realistic constraints.
5. See consequences of those decisions.
6. End with a reflection report showing skills used, strengths, mistakes, and whether the career felt like a good fit.

The app should not start with a default career. The student must choose a role from the library or recommendations first.

## Current App

The app is now a complete static web app with:

- Dashboard with product overview and saved progress stats
- Learner profile onboarding for interests, decision style, and difficulty
- Career library with search, field filter, intensity filter, and sorting
- 50+ playable careers
- Career preview panel with mission, stakeholder, pressure, tools, and prior best score
- Deep authored scenario packs for popular roles including Product Manager, Software Engineer, Doctor, Lawyer, Teacher, Entrepreneur, UX Designer, and Data Analyst
- Six-step workday simulation for every career
- Replay variation so the same role can feel different on later runs
- Difficulty modes: Beginner guidance, Realistic pressure, and Challenge mode
- Workspace tabs for inbox, chat, tasks, calendar, and documents
- Skill scoring across clarity, empathy, execution, and ethics
- Energy, stress, progress, and timeline indicators
- End-of-day report modal
- Achievements such as First Workday, Career Explorer, Clear Communicator, Calm Under Pressure, Ethical Decision Maker, Systems Thinker, and People Helper
- Local browser progress history using `localStorage`
- Role recommendations after each completed day
- Progress page with history and suggested next careers
- Downloadable counselor/classroom summaries

## What Should Make It Unique

- Realistic career situations, not textbook descriptions
- Interactive emails, chats, meetings, and task boards
- Choices with tradeoffs instead of obvious right answers
- Role-specific skills and feedback
- Replayable days with different outcomes
- Student-friendly explanations after each decision
- A final career fit reflection instead of only a score

## Future Improvements

Possible next upgrades:

- Add authored premium scenarios for the most popular roles
- Add AI-generated variations after the rule-based loop is validated
- Add user accounts and cloud progress sync
- Add classroom mode for teachers and counselors
- Add career comparison reports
- Add audio or video meeting moments

## Tech Stack

The app uses HTML, CSS, and JavaScript with an optional dependency-free Node server.

No install step is required. Open `index.html` directly for the static version, or run `npm start` to serve the app with the local API scaffold.

## Files

- `index.html` - app shell and views
- `styles.css` - responsive product UI
- `app.js` - career data, simulation engine, scoring, persistence, and rendering
- `server.js` - dependency-free local server and JSON API scaffold
- `data/db.json` - local development data store for server mode
- `manifest.json` and `icon.svg` - installable app shell assets
- `AGENTS.md` - project instructions for future agents

## Commands

- Install: no install needed
- Dev: open `index.html` in a browser, or run `npm start` and visit `http://localhost:4173`
- Build: no build step
- Test: manually complete at least three simulations and verify progress history
- Syntax check: `npm run check`

## Development Notes

- Prioritize realism, clarity, and replayability.
- Keep the interface modern and easy for students to understand.
- Avoid making the product feel like a static quiz or article.
- Keep the app dependency-free unless a framework becomes clearly useful.
- The simulation engine is rule-based with authored packs plus adaptive fallback scenarios.
- AI-generated scenarios can be added later through the scenario-pack boundary in `app.js`, after the rule-based loop is validated.

## Career Source Notes

The career list is inspired by broad occupation coverage from the U.S. Bureau of Labor Statistics Occupational Outlook Handbook and common student-facing career exploration categories.
