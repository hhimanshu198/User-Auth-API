# AGENTS.md

## Project Overview
- **Project:** SkillRova - a career simulator that lets students experience realistic "one day in the life" career simulations through emails, meetings, tasks, tradeoffs, pressure, and reflection reports.
- **Target user:** Students aged 12-25 who want to understand what different careers actually feel like before choosing a path.
- **My skill level:** beginner / intermediate
- **Stack:** Static HTML, CSS, and JavaScript. No build step yet.

## Product Direction
- Support many playable career simulations, while keeping each role grounded in realistic workplace pressure.
- Keep top roles deeper than the long-tail library. Popular roles should use authored scenario packs where possible.
- Do not start Product Manager or any other role by default. The student must choose a career first.
- Make the experience feel like an interactive workday, not a quiz or static career guide.
- Use realistic workplace moments: inbox messages, chat threads, task boards, calendar events, documents, stakeholder requests, ambiguous decisions, and time pressure.
- Keep the tone modern, practical, and student-friendly.
- Design for replayability with different choices, outcomes, skill feedback, and reflection at the end of each day.
- The app should feel more immersive and useful than existing career exploration tools.
- Preserve learner profile, achievements, progress history, and counselor summary features.

## Commands
- **Install:** No install needed for the current static MVP
- **Dev:** Open `index.html` in a browser
- **Build:** No build step yet
- **Test:** Run `node --check app.js`, then manually play at least three career simulations in the browser
- **Lint:** No lint command yet

## Do
- Read existing code before modifying anything
- Match existing patterns, naming, and style
- Handle errors gracefully - no silent failures
- Keep changes small and scoped to what was asked
- Run dev/build after changes to verify nothing broke
- Ask clarifying questions before guessing major product or architecture decisions
- Keep the target audience in mind: students aged 12-25
- Make the product feel interactive, realistic, and useful
- Preserve localStorage progress behavior unless replacing it with a real backend
- Keep the authored scenario pack boundary clean so AI-generated scenario variations can be added later

## Don't
- Install new dependencies without asking
- Delete or overwrite files without confirming
- Hardcode secrets, API keys, or credentials
- Rewrite working code unless explicitly asked
- Push, deploy, or force-push without permission
- Make changes outside the scope of the request
- Turn the app into a generic career quiz
- Use boring placeholder gameplay when a realistic simulation would be better
- Add a framework or dependency without a clear product reason

## When Stuck
- If a task is large, break it into steps and confirm the plan first
- If you can't fix an error in 2 attempts, stop and explain the issue

## Testing
- Run existing tests after any change
- Add at least one test for new features
- Never skip or delete tests to make things pass
- For simulations, test successful, mixed, and poor decision paths where possible
- Verify saved progress appears on the dashboard and progress page
- Verify profile recommendations, difficulty modes, achievements, and downloadable summaries

## Git
- Small, focused commits with descriptive messages
- Never force push

## Response Style
- Always respond with clear and concise messages
- Use plain English when explaining to the User
- Avoid long sentences, complex words, or long paragraphs
